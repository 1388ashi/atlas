<?php

namespace Modules\Attribute\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class AttributeUpdateRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     * در ویرایش نوع نمیتواند تغییر کند
     * @return array
     */
    public function rules()
    {
        return [
            'name' => ['required', 'string', 'max:191', Rule::unique('attributes')->ignore($this->route('attribute'))],
            'label' => 'required|string|max:191',
            'show_filter' => 'required|boolean',
            'public' => 'required|boolean',
            'status' => 'required|boolean',
            'style' => 'nullable|string|in:select,box',
            // برای دادن مقادیر جدید ولیوز میدیم در غیر اینصورت برای ویرایش ادیتد ولیو
            'values' => 'nullable|array',
            'values.*' => 'nullable|string|max:191',
            'edited_values' => 'nullable|array',
            'edited_values.*' => 'nullable',
            'edited_values.*.id' => 'required_if:type,select',
            'edited_values.*.value' => 'required_if:type,select|string|max:191',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function prepareForValidation()
    {
        $this->merge([
            'show_filter' => $this->show_filter ? 1 : 0,
            'status' => $this->status ? 1 : 0,
            'public' => $this->public ? 1 : 0
        ]);
    }
}
