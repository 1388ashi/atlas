<?php

namespace Modules\Attribute\Http\Controllers\Admin;

use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controller;
use Modules\Attribute\Entities\Attribute;
use Modules\Attribute\Http\Requests\Admin\AttributeStoreRequest;
use Modules\Attribute\Http\Requests\Admin\AttributeUpdateRequest;

class AttributeController extends Controller
{
    public function index(): JsonResponse
    {
        $attributes = Attribute::latest('id')->withCommonRelations()->filters()->paginateOrAll();

        return response()->success('دریافت لیست ویژگی ها', compact('attributes'));
    }

    public function store(AttributeStoreRequest $request): JsonResponse
    {
        $attribute = Attribute::create($request->all());

        if ($request->type === 'select' && $request->values) {
            foreach ($request->values as $value) {
                $attribute->values()->create([
                    'value' => $value
                ]);
            }
        }
        $attribute->load('values');

        return response()->success('ویژگی با موفقیت ثبت شد', compact('attribute'));
    }

    public function show($id): JsonResponse
    {
        $attribute = Attribute::findOrfail($id);
        $attribute->loadCommonRelations();

        return response()->success('ویژگی با موفقیت دریافت شد', compact('attribute'));
    }

    public function update(AttributeUpdateRequest $request, $id): JsonResponse
    {
        $attribute = Attribute::findOrfail($id);
        $attribute->update($request->validated());

        if ($attribute->type === 'select' && $request->values) {
//            $attribute->values()->delete(); نباید بشه حذف کرد خراب میشه
            foreach ($request->values as $value) {
                // If already exists don't add
                if (!$attribute->values()->where('value', $value)->exists()) {
                    $attribute->values()->create([
                        'value' => $value
                    ]);
                }
            }
            // مقادیری که ویرایش شده
            foreach ($request->input('edited_values') as $editedValue) {
                $attributeValue = $attribute->values()->find($editedValue['id']);
                if (!$attributeValue) {
                    continue;
                }
                $attributeValue->value = $editedValue['value'];
                $attributeValue->save();
            }
        }
        $attribute->loadCommonRelations();

        return response()->success('ویژگی با موفقیت به روزرسانی شد', compact('attribute'));
    }

    public function destroy($id): JsonResponse
    {
        $attribute = Attribute::findOrfail($id);

        $attribute->delete();

        return response()->success('ویژگی با موفقیت حذف شد', compact('attribute'));
    }
}
