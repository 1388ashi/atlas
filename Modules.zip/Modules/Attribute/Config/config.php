<?php

return [
    'name' => 'Attribute'
];
