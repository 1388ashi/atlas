<?php

namespace Modules\Attribute\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Core\Entities\HasCommonRelations;
use Modules\Core\Traits\HasAuthors;

class AttributeValue extends Model
{
    use HasFactory, HasAuthors, HasCommonRelations;

    protected $fillable = [
        'value', 'selected'
    ];

    protected static function newFactory()
    {
        return \Modules\Attribute\Database\factories\AttributeValueFactory::new();
    }

    //Relations

    public function attribute()
    {
        return $this->belongsTo(Attribute::class);
    }
}
