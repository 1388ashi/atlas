<?php

namespace Modules\Attribute\Entities;

use AjCastro\EagerLoadPivotRelations\EagerLoadPivotTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Core\Entities\BaseModel;
use Modules\Core\Entities\HasCommonRelations;
use Modules\Core\Helpers\Helpers;
use Modules\Core\Traits\HasAuthors;
use Modules\Core\Traits\HasDefaultFields;
use Modules\Product\Entities\Variety;

class Attribute extends BaseModel
{
    use HasFactory, HasAuthors, HasCommonRelations, EagerLoadPivotTrait, HasDefaultFields;

    protected $defaults = [
        'style' => 'select'
    ];

    protected static $commonRelations = [
        'values'
    ];

    protected $fillable = [
        'name',
        'label',
        'type',
        'show_filter',
        'public',
        'style',
        'status'
    ];

    const TYPE_SELECT = 'select';
    const TYPE_TEXT = 'text';

    public static function booted()
    {
        static::deleting(function (Attribute $attribute) {
            if ($attribute->varieties()->exists()) {
                throw Helpers::makeValidationException('به علت استفاده شدن در یک محصول امکان حذف آن وجود ندارد');
            }
        });
    }

    protected static function newFactory()
    {
        return \Modules\Attribute\Database\factories\AttributeFactory::new();
    }

    //Relations

    public function values()
    {
        return $this->hasMany(AttributeValue::class, 'attribute_id');
    }

    public function varieties(): \Illuminate\Database\Eloquent\Relations\BelongsToMany
    {
        return $this->belongsToMany(Variety::class);
    }

    public static function getAvailableType(): array
    {
        return [static::TYPE_TEXT,static::TYPE_SELECT];
    }

    public function scopeActive($query)
    {
        $query->where('status' , true);
    }
}
