<?php


namespace Modules\Dashboard\Services;


use Illuminate\Support\Carbon;
use JetBrains\PhpStorm\ArrayShape;
use Laravel\Sanctum\PersonalAccessToken;
use Modules\Customer\Entities\Customer;
use Modules\Order\Entities\Order;
use Modules\Order\Entities\OrderItem;
use Spatie\Activitylog\Models\Activity;
use stdClass;

class ReportService
{
    public function getByYear($offsetYear = 0): array
    {
        $currentMonth = verta()->subYears($offsetYear)->startYear()->startMonth();
        $yearStatistics = [];
        foreach (range(1, 12) as $month) {
            $l = $currentMonth->clone()->startMonth();
            $r = $currentMonth->clone()->endMonth();

            $yearStatistics[$month] = $this->salesAmountByDate(
                Carbon::instance($l->datetime()),
                Carbon::instance($r->datetime()),
            );
            $currentMonth = $currentMonth->addMonth();
        }

        return $yearStatistics;
    }

    public function getByMonth($month, $offsetYear = 0): array
    {
        $currentDay = verta()->subYears($offsetYear)->month($month)->startMonth()->startDay();
        $monthStatistics = [];
        $totalDaysInMonth = (int)$currentDay->clone()->endMonth()->format('d');
        foreach (range(1, $totalDaysInMonth) as $day) {
            $l = $currentDay->clone()->startDay();
            $r = $currentDay->clone()->endDay();

            $monthStatistics[$day] = $this->salesAmountByDate(
                Carbon::instance($l->datetime()),
                Carbon::instance($r->datetime()),
            );
            $currentDay = $currentDay->addDay();
        }

        return $monthStatistics;
    }

    public function getByWeek(): array
    {
        $currentDay = verta()->startWeek()->startDay();
        $weekStatistics = [];
        foreach (range(1, 7) as $day) {
            $l = $currentDay->clone()->startDay();
            $r = $currentDay->clone()->endDay();

            $weekStatistics[$day] = $this->salesAmountByDate(
                Carbon::instance($l->datetime()),
                Carbon::instance($r->datetime()),
            );
            $currentDay = $currentDay->addDay();
        }

        return $weekStatistics;
    }


    #[ArrayShape(['males_count' => "int", 'females_count' => "int", 'unknowns_count' => "int"])]
    public function getCustomersGender(): array
    {
        $malesCount = Customer::query()->where('gender', Customer::MALE)->count();
        $femalesCount = Customer::query()->where('gender', Customer::FEMALE)->count();
        $allCount = Customer::query()->count();

        return [
            'males_count' => $malesCount,
            'females_count' => $femalesCount,
            'unknowns_count' => $allCount - $femalesCount - $malesCount
        ];
    }

    public function getLogs($limit = 6): \Illuminate\Database\Eloquent\Collection|array
    {
        return Activity::query()->limit($limit)->latest('id')
            ->get(['id', 'subject_type', 'description', 'event']);
    }

    // گرفتن تعداد سفارشات بر اساس وضعیت در 7 روز هفته
    public function getOrdersByStatus(): array
    {
        $currentDay = verta()->startWeek();
        $weekStatistics = [];
        foreach (range(1, 7) as $day) {
            $l = $currentDay->clone()->startDay();
            $r = $currentDay->clone()->endDay();

            $weekStatistics[$day] = $this->ordersStatusByDate(
                Carbon::instance($l->datetime()),
                Carbon::instance($r->datetime()),
            );
            $currentDay = $currentDay->addDay();
        }

        return $weekStatistics;
    }


    public function salesAmountByDate(Carbon $startDate= null, Carbon $endDate = null): StdClass
    {
        $dateFilter = $startDate && $endDate ? "and `order_items`.`created_at` > '{$startDate->toDateTimeString()}'
         and `order_items`.`created_at` < '{$endDate->toDateTimeString()}'" : "";
        $sums = \DB::select("select IFNULL(SUM((order_items.amount) * order_items.quantity) , 0) AS amount,
       IFNULL(SUM(order_items.discount_amount * order_items.quantity) ,0) AS discount_amount,
       IFNULL(SUM(order_items.quantity), 0) AS quantity from `order_items`
           inner join `orders` on `orders`.`id` = `order_items`.`order_id`
where `order_items`.`status` = 1 and `orders`.`status` not in ('canceled', 'wait_for_payment')" . $dateFilter);

        return $sums[0];
    }


    public function getLastLogins()
    {
        return PersonalAccessToken::latest('id')
            ->select(['id', 'tokenable_id', 'tokenable_type', 'created_at'])
            ->take(4)->with('tokenable')->get();
    }

    protected function ordersStatusByDate(Carbon $startDate= null, Carbon $endDate = null)
    {
        $statuses = [];
        $orderQuery = Order::query()->whereBetween('created_at', [$startDate,$endDate]);
        $statuses[Order::STATUS_NEW] = $orderQuery->clone()->where('status', Order::STATUS_NEW)->count();
        $statuses[Order::STATUS_WAIT_FOR_PAYMENT]= $orderQuery->clone()->where('status', Order::STATUS_WAIT_FOR_PAYMENT)->count();
        $statuses[Order::STATUS_CANCELED]=$orderQuery->clone()->where('status', Order::STATUS_CANCELED)->count();
        $statuses[Order::STATUS_DELIVERED]=$orderQuery->clone()->where('status', Order::STATUS_DELIVERED)->count();
        $statuses[Order::STATUS_IN_PROGRESS]=$orderQuery->clone()->where('status', Order::STATUS_IN_PROGRESS)->count();

        return $statuses;
    }
}
