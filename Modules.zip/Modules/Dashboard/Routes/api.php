<?php

Route::superGroup('admin' ,function () {
    Route::apiResource('dashboard', 'DashboardController');
});
