<?php

namespace Modules\Dashboard\Http\Controllers\Admin;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Database\Query\Builder;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Carbon;
use Modules\Comment\Entities\Comment;
use Modules\Contact\Entities\Contact;
use Modules\Dashboard\Services\ReportService;
use Modules\Order\Entities\Order;
use Modules\Order\Entities\OrderItem;
use Modules\Product\Entities\Product;
use Modules\ProductComment\Entities\ProductComment;

class DashboardController extends Controller
{
    public function __construct(protected ReportService $reportService) {}

    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $order =  Order::query()->select('id', 'status')
            ->whereNotIn('status', [Order::STATUS_CANCELED, Order::STATUS_WAIT_FOR_PAYMENT]);
        $salesAmountByToday = $this->reportService->salesAmountByDate(Carbon::now()->startOfDay(), Carbon::now()->endOfDay());
        $salesAmountByMonth = $this->reportService->salesAmountByDate(Carbon::now()->startOfMonth(), Carbon::now()->endOfMonth());
        $ordersCount = $order->count();
        $lastOrders = Order::withCommonRelations()->latest('id')->take(7)->get()->append('total_amount');
        $contacts = Contact::query()->take(5)->latest('id')->get();
        $productComments = ProductComment::query()->latest('id')->with(['creator', 'product'])
            ->take(6)->get();
        $newProductCommentsCount = ProductComment::query()->latest('id')
            ->whereStatus(ProductComment::STATUS_PENDING)->count();
        $blogComments = Comment::query()->with('commentable')->take(6)->get();
        $newBlogCommentsCount = Comment::query()
            ->whereStatus(Comment::STATUS_PENDING)->count();

        $data = [
            'orders_count' => $ordersCount,
            'sales_amount_by_today' => $salesAmountByToday,
            'sales_amount_by_month' => $salesAmountByMonth,
            'year_statistics' => $this->reportService->getByYear(0),
            'gender_statistics' => $this->reportService->getCustomersGender(),
            'logs' => $this->reportService->getLogs(),
            'orders_by_status' => $this->reportService->getOrdersByStatus(),
            'last_logins' => $this->reportService->getLastLogins(),
            'last_orders' => $lastOrders,
            'contacts' => $contacts,
            'comments' => [
                'product_comments' => $productComments,
                'new_product_comments_count' => $newProductCommentsCount,
                'blog_comments' => $blogComments,
                'new_blog_comments_count' => $newBlogCommentsCount
            ]
        ];

        return response()->success('', $data);
    }
}
