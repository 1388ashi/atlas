<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Modules\Customer\Entities\Customer;

class CreateCustomersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->id();
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('mobile', 20)->unique();
            $table->string('password');
            $table->string('email')->nullable()->unique();
            $table->string('national_code', 20)->nullable();
            $table->enum('gender', Customer::getAvailableGenders())->nullable();
            $table->string('card_number')->nullable();
            $table->date('birth_date')->nullable();
            $table->boolean('newsletter')->default(0);
            $table->boolean('foreign_national')->default(0);
            $table->timestamp('mobile_verified_at')->nullable();
            $table->rememberToken();
            $table->authors();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customers');
    }
}
