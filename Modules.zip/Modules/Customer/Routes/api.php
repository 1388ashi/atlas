<?php

use Modules\Customer\Http\Controllers\Admin\CustomerController;
use Modules\Customer\Http\Controllers\Customer\ProfileController;

Route::superGroup('admin', function () {
    Route::get('customers/transactions', 'CustomerController@transactionsWallet')
        ->name('customers.transactions.index')->hasPermission('read_transaction');

    Route::permissionResource('customers', 'CustomerController');

    Route::post('customer/deposit', [CustomerController::class, 'depositCustomerWallet'])
        ->name('customer.deposit')
        ->hasPermission('modify_customer');

    Route::post('customer/withdraw', [CustomerController::class, 'withdrawCustomerWallet'])
        ->name('customer.withdraw')
        ->hasPermission('modify_customer');

    Route::delete('customers/addresses/{customer}/{address}', 'AddressController@destroy');

    Route::apiResource('customers/addresses', 'AddressController')
        ->only(['store', 'update']);
});

Route::superGroup('customer', function () {
    //profile
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::put('/profile/image', [ProfileController::class, 'uploadImage'])->name('profile.uploadImage');
    //password
    Route::put('/password', [ProfileController::class, 'changePassword'])->name('password');
    //address
    Route::apiResource('addresses', 'AddressController')->only(['store', 'update', 'destroy']);
    //wallet
    Route::post('/deposit', [ProfileController::class, 'depositWallet'])->name('profile.deposit');
    Route::post('/transactions', [ProfileController::class, 'transactionsWallet'])->name('profile.transactionsWallet');
});
