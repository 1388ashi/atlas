<?php

namespace Modules\Customer\Entities;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Core\Entities\BaseModel;
use Modules\Core\Entities\HasCommonRelations;

class SmsToken extends BaseModel
{
    use HasFactory, HasCommonRelations;

    protected $fillable = [
        'mobile', 'token', 'expired_at'
    ];

    protected $dates = [
        'expired_at', 'verified_at'
    ];

    protected static function newFactory()
    {
        return \Modules\Customer\Database\factories\SmsTokenFactory::new();
    }
}
