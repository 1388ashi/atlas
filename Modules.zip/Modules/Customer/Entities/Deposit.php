<?php

namespace Modules\Customer\Entities;

use Modules\Admin\Entities\Admin;
use Modules\Core\Entities\BaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Core\Helpers\Helpers;
use Modules\Invoice\Classes\Payable;
use Modules\Invoice\Entities\Invoice;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class Deposit extends Payable
{
    use HasFactory, LogsActivity;


    const STATUS_NEW = 'new';
    const STATUS_WAIT_FOR_PAYMENT = 'wait_for_payment';
    const STATUS_IN_PROGRESS = 'in_progress';
    const STATUS_SUCCESS = 'success';
    const STATUS_CANCELED = 'canceled';

    protected static $recordEvents = ['created'];

    protected $fillable = [
        'amount',
        'status'
    ];

    public function getActivitylogOptions(): LogOptions
    {
        $user = \Auth::user();
        if($user instanceof Admin) {
            $message = "ادمین با شناسه {$user->id} کیف پول کاربر با شناسه {$this->id} را شارژ کرد";
        }else{
            $message = "کاربر با شماره موبایل {$this->mobile} کیف پول خود را شارژکرد";
        }
        return LogOptions::defaults()
            ->useLogName('Wallet')
            ->logAll()
            ->logOnlyDirty()
            ->setDescriptionForEvent(function($eventName) use ($message){
                return $message;
            });
    }

    public static function getAvailableStatus(): array
    {
        return [static::STATUS_NEW, static::STATUS_WAIT_FOR_PAYMENT, static::STATUS_IN_PROGRESS,
            static::STATUS_SUCCESS, static::STATUS_CANCELED];
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public static function storeModel($amount)
    {
        $user = \Auth::user();
        $deposit = new self;

        $deposit->fill([
            'amount' =>  $amount,
            'status' => static::STATUS_WAIT_FOR_PAYMENT
        ]);
        $deposit->customer()->associate($user->id);
        $deposit->save();

        return $deposit;
    }

    public function isPayable(): bool
    {
        return $this->status === static::STATUS_WAIT_FOR_PAYMENT;
    }

    public function getPayableAmount(): int
    {
        return (int)$this->amount;
    }

    public function onSuccessPayment(Invoice $invoice): \Illuminate\Contracts\View\View|\Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\Contracts\Foundation\Application
    {
        $customer = $invoice->payable->customer()->first();
        $customer->deposit($invoice->amount);

        $this->status = static::STATUS_SUCCESS;
        $this->save();
        $type = 'wallet';

        return view('invoice::callback', ['invoice' => $invoice, 'type' => $type]);
    }
}
