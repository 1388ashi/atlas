<?php

namespace Modules\Customer\Http\Requests\Customer;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Modules\Customer\Entities\Customer;

class CustomerStoreRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first_name' => 'nullable|string|min:3|max:120',
            'last_name' => 'nullable|string|min:3|max:120',
            'email' => 'nullable|unique:customers,email',
            'password' => 'required|string|min:6',
            'mobile' => 'required|unique:customers,mobile',
            'national_code' => 'nullable|string|size:10|digits:10',
            'gender' => ['nullable', Rule::in(Customer::getAvailableGenders())],
            'card_number' => 'nullable|string',
            'birth_date' => 'nullable|date',
            'newsletter' => 'nullable|boolean',
            'foreign_national' => 'nullable|boolean',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
}
