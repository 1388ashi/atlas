<?php

namespace Modules\Customer\Http\Controllers\Customer;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Modules\Core\Helpers\Helpers;
use Modules\Core\Rules\Base64Image;
use Modules\Customer\Entities\Customer;
use Modules\Customer\Entities\Deposit;
use Modules\Customer\Http\Requests\Customer\ChangePasswordRequest;
use Modules\Customer\Http\Requests\Customer\ProfileUpdateRequest;
use Modules\Invoice\Entities\Invoice;
use Modules\Invoice\Entities\Payment;
use Throwable;

class ProfileController extends Controller
{

    private null|\Illuminate\Contracts\Auth\Authenticatable|Customer $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next){
            $this->user = auth()->user();

            return $next($request);
        });
    }

    public function edit()
    {
        $customer = $this->user;
        $customer->loadCommonRelations();

        return response()->success('دریافت اطلاعات پروفایل مشتری', compact('customer'));
    }

    public function update(ProfileUpdateRequest $request)
    {
        $customer = auth()->user();

        $customer->fill($request->only([
            'first_name',
            'last_name',
            'email',
            'national_code',
            'gender',
            'card_number',
            'birth_date',
            'newsletter',
            'foreign_national'
        ]));
        if ($request->filled('password')) {
            $customer->password = $request->input('password');
        }
        $customer->save();

        if($request->hasFile('image')){
            $customer->addImage($request->image);
        }

        $customer->loadCommonRelations();

        return response()->success('پروفایل کاربر با موفقیت به روزرسانی شد', ['1' => $customer]);
    }

    public function changePassword(ChangePasswordRequest $request)
    {
        $customer = $this->user;

        $customer->fill(['password' => $request->password])->save();

        return response()->success('کلمه عبور با موفقیت تغییر کرد.');
    }

    public function depositWallet(Request $request)
    {
        $request->validate([
            'amount' => 'required|integer|min:1000'
        ]);

        try {
            $deposit = Deposit::storeModel($request->amount);

            return $deposit->pay();
        } catch (Throwable $e) {
            throw Helpers::makeValidationException('عملیات شارژ کیف پول ناموفق بود،لطفا دوباره تلاش کنید.'.$e->getMessage());
        }
    }

    public function transactionsWallet(): \Illuminate\Http\JsonResponse
    {
        /** @var Customer $customer */
        $customer = auth()->user();
        $transactions = $customer->transactions();
        Helpers::applyFilters($transactions);
        $transactions = Helpers::paginateOrAll($transactions);

        return response()->success('گزارشات کیف پول شما', compact('transactions'));
    }

    public function uploadImage(Request $request)
    {
        $request->validate([
            'image' => ['required','string', new Base64Image()]
        ]);

        $image = $this->user->addImage($request->image);

        return response()->success('عکس پروفایل با موفقیت ویرایش شد', compact('image'));
    }
}
