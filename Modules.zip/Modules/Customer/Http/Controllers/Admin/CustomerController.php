<?php

namespace Modules\Customer\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Core\Classes\Transaction;
use Modules\Core\Helpers\Helpers;
use Modules\Customer\Entities\Address;
use Modules\Customer\Entities\Customer;
use Modules\Customer\Entities\Deposit;
use Modules\Customer\Http\Requests\Customer\CustomerStoreRequest;
use Modules\Customer\Http\Requests\Customer\CustomerUpdateRequest;
use phpDocumentor\Reflection\DocBlock\Description;

class CustomerController extends Controller
{
    public function index()
    {
        $customers = Customer::latest('id');
        Helpers::applyFilters($customers);
        $customers = Helpers::paginateOrAll($customers);

        return response()->success('دریافت لیست همه مشتری ها', compact('customers'));
    }

    public function listCustomers()
    {
        $customers = Customer::latest('id')->select('id', 'first_name', 'last_name', 'mobile')->without('wallet')->get();

        return response()->success('', compact('customers'));
    }

    public function show($id)
    {
        $customer = Customer::query()->withCommonRelations()->findOrFail($id);

        return response()->success('دریافت جزئیات مشتری', [$customer]);
    }

    public function depositCustomerWallet(Request $request): \Illuminate\Http\JsonResponse
    {
        $request->validate([
            'customer_id' => 'required|integer|exists:customers,id',
            'amount' => 'required|integer|min:1000',
            'description' => 'nullable|string'
        ]);
        /**
         * @var $customer Customer
         */
        $customer = Customer::query()->whereKey($request->customer_id)->first();
        $full_name = $customer->first_name.' '. $customer->last_name;
        $customer->deposit($request->amount, [
            'admin_id' => auth()->user()->id,
            'description' => $request->description ?? " افزایش موجودی حساب توسط ادمین با شناسه ".auth()->user()->id
        ]);

        return response()->success("کیف پول مشتری {$full_name} با موفقیت به مبلغ {$request->amount} افزایش یافت");
    }

    public function store(CustomerStoreRequest $request): \Illuminate\Http\JsonResponse
    {
        $customer = Customer::query()->create($request->all());

        return response()->success('مشتری با موفقیت ایجاد شد.', compact('customer'));
    }

    public function Update(CustomerUpdateRequest $request, $id): \Illuminate\Http\JsonResponse
    {
        $customer = Customer::query()->findOrFail($id);
        $customer->update($request->all());
        $customer->loadCommonRelations();

        return response()->success('مشتری با موفقیت بروزرسانی شد.', compact('customer'));
    }

    public function destroy($id): \Illuminate\Http\JsonResponse
    {
        $customer = Customer::query()->findOrFail($id);
        $customer->delete();

        return response()->success('مشتری با موفقیت حذف شد.', compact('customer'));
    }

    public function transactionsWallet(): \Illuminate\Http\JsonResponse
    {
        $transactions = Transaction::query()->where('payable_type', Customer::class)
            ->latest('id')->with('transfers');
        if ($customerId = \request('customer_id')) {
            $transactions->where('payable_id', $customerId);
        }
        $transactions = $transactions->paginate();

        return response()->success('گزارشات کیف پول', compact('transactions'));
    }

    public function withdrawCustomerWallet(Request $request): \Illuminate\Http\JsonResponse
    {
        $request->validate([
            'customer_id' => 'required|integer|exists:customers,id',
            'amount' => 'required|integer|min:1000',
            'description' => 'nullable|string'
        ]);

        $admin = auth()->user();
        /** @var Customer $customer */
        $customer = Customer::query()->find($request->customer_id);
        $customer->withdraw($request->amount, [
            'description' => $request->description ?? "کاهش موجودیی کیف پول توسط ادمین با شناسه {$admin->id}"
        ]);

        return response()->success('مبلغ مورد نظر از کیف پول مشتری با موفقیت کسر گردید', compact('customer'));
    }
}
