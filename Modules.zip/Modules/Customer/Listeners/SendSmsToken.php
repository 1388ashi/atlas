<?php

namespace Modules\Customer\Listeners;

use Carbon\Carbon;
use Modules\Core\Helpers\Helpers;
use Modules\Customer\Entities\SmsToken;
use Modules\Customer\Events\SmsVerify;

class SendSmsToken
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param SmsVerify $event
     * @return array
     */
    public function handle(SmsVerify $event): array
    {
        $sms = resolve('Sms');
        $token = Helpers::randomNumbersCode(5);
        //$output = $sms->lookup($event->mobile, $token, '', '', 'verify');
        $output = $sms->send($event->mobile, "کد فعالسازی شما در شاپیت {$token} است.");
        if ($output['success']) {
            //store into database
            $smsToken = SmsToken::where('mobile', $event->mobile)->first();
            if ($smsToken) {
                $smsToken->update([
                    'token' => $token,
                    'expired_at' => Carbon::now()->addHours(24)
                ]);
            } else {
                SmsToken::create([
                    'mobile' => $event->mobile,
                    'token' => $token,
                    'expired_at' => Carbon::now()->addHours(24)
                ]);
            }
        }

        return $output;
    }
}
