<?php

namespace Modules\Customer\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Modules\Core\Channels\SmsChannel;
use Modules\Order\Entities\Order;

class InvoicePaid extends Notification implements ShouldQueue
{
    use Queueable;

    public Order $order;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(Order $order)
    {
        $customer = $order->customer;
        $activeItems = $order->activeItems;
        $this->order = $order->withoutRelations();
        $this->order->setRelation('customer', $customer);
        $this->order->setRelation('activeItems', $activeItems);
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail', 'database', SmsChannel::class];
    }


    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->from('atlas@gmail.com', 'kom')
                    ->line('فاکتور خرید شما')
                    ->line('خرید با موفقیت انجام شد.')
                    ->line("مبلغ خرید شما {$this->order->getTotalAmount()}")
                    ->line("کد رهگیری {$this->order->tracking_code}")
                    ->action('اطلس مد', 'https://atlas.com');
    }

    public function toDatabase()
    {
        return [
            'product' => $this->order->activeItems,
            'amount' => $this->order->getTotalAmount(),
            'invoice_action' => 'paid',
            'description' => 'خرید شما با موفقیت انجام شد.',
            'tracking_code' => $this->order->tracking_code
        ];
    }

    public function toSms($notifiable)
    {
        return [
            'mobile' => $this->order->customer->mobile,
            'message' => "سلام اطلسی عزیز
خرید شما با موفقیت انجام شد.
کد رهگیری شما :{$this->order->tracking_code} "
        ];
    }


    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
