<?php

namespace Modules\Admin\Entities;

use Illuminate\Contracts\Auth\Guard;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Modules\Core\Helpers\Helpers;
use Spatie\Permission\Traits\HasRoles;


/**
 * @method static find(int $int)
 */
class Admin extends Authenticatable implements \Modules\Core\Contracts\Notifiable
{
    use HasFactory, HasApiTokens, HasRoles, Notifiable;

    protected $guard_name = 'admin-api';

    protected $fillable = [
        'name',
        'username',
        'password',
        'email',
        'mobile',
    ];

    protected $appends = ['role'];
    protected $hidden = ['roles', 'updater'];

    protected static function booted()
    {
        parent::booted();
        static::updating(function($admin){
            if (!auth()->user()->hasRole('super_admin') && $admin->hasRole('super_admin')){
                return throw Helpers::makeValidationException('شما مجاز به ویرایش سوپر ادمین نمیباشید');
            }
        });
    }

    public function setPasswordAttribute($value)
    {
        if ($value != null){
            $this->attributes['password'] = bcrypt($value);
        }
    }

    public function getRoleAttribute()
    {
        $roles = $this->roles;
        if (empty($roles)) {
            return null;
        }
        return  $roles[0];
    }
}
