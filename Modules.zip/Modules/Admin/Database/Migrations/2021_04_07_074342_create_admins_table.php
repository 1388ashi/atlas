<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Modules\Admin\Entities\Admin;

class CreateAdminsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('admins', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
            $table->string('username' , 20)->unique()->index();
            $table->string('email' , 100)->unique()->nullable();
            $table->string('password');
            $table->string('mobile' , 20)->unique()->nullable();
            $table->timestamps();
        });

        Admin::query()->create([
            'name' => 'admin',
            'username' => 'admin',
            'password' => '123456',
            'email' => 'Admin@gmail.com',
            'mobile' => '09112541526',
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admins');
    }
}
