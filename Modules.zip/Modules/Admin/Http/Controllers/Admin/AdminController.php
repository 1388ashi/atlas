<?php

namespace Modules\Admin\Http\Controllers\Admin;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Admin\Entities\Admin;
use Modules\Admin\Http\Requests\AdminStoreRequest;
use Modules\Admin\Http\Requests\AdminUpdateRequest;
use Modules\Core\Helpers\Helpers;
use Spatie\Permission\Models\Role;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return JsonResponse
     */
    public function index(): JsonResponse
    {
        $admins = Admin::query()->with('roles.permissions');
        Helpers::applyFilters($admins);
        $admins = Helpers::paginateOrAll($admins);

        return response()->success('لیست ادمین ها', compact('admins'));
    }

    /**
     * Store a newly created resource in storage.
     * @param AdminStoreRequest $request
     * @return JsonResponse
     */
    public function store(AdminStoreRequest $request): JsonResponse
    {
        $admin = Admin::query()->create($request->all());
        $role = Role::findById($request->role);
        $admin->assignRole($role);

        return response()->success("ادمین با موفقیت ساخته شد.", compact('admin'));
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return JsonResponse
     */
    public function show($id): JsonResponse
    {
        $admin = Admin::query()->with('roles.permissions')->findOrFail($id);

        return response()->success('', compact('admin'));
    }

    /**
     * Update the specified resource in storage.
     * @param AdminUpdateRequest $request
     * @param int $id
     * @return JsonResponse
     */
    public function update(AdminUpdateRequest $request, $id): JsonResponse
    {
        $admin = Admin::query()->findOrFail($id);
        $admin->update($request->all());
        if ($request->role){
            $role = Role::findById($request->role);
            $admin->syncRoles($role);
        }

        return response()->success('باموفقیت بروزرسانی شد', compact('admin'));
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return JsonResponse
     */
    public function destroy($id): JsonResponse
    {
        $admin = Admin::query()->findOrFail($id);
        if ($admin->hasRole('super_admin')){
            return throw Helpers::makeValidationException('شما مجاز به حذف سوپر ادمین نمیباشید', 'role');
        }
        $admin->delete();

        return response()->success('باموفقیت حذف شد', compact('admin'));
    }
}
