<?php


namespace Modules\Core\Helpers;


use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;
use Intervention\Image\Image;
use JetBrains\PhpStorm\NoReturn;
use Kalnoy\Nestedset\QueryBuilder;
use Spatie\MediaLibrary\MediaCollections\Models\Collections\MediaCollection;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class Helpers
{
    /**
     * @return \Illuminate\Contracts\Auth\Authenticatable|Model
     */
    public static function getAuthenticatedUser()
    {
        foreach(array_keys(config('auth.guards')) as $guard){
            if(auth()->guard($guard)->check()) {
                return auth()->guard($guard)->user();
            }
        }

        return null;
    }

    public static function resizeImageWithAspectRatio(Image $image, $width, $height)
    {
        $image->height() > $image->width() ? $width = null : $height = null;
        $image->resize($width, $height, function ($constraint) {
            $constraint->aspectRatio();
        });

        return $image;
    }

    public static function resizeImage(Image $image, $width, $height)
    {
        $image->resize($width, $height);

        return $image;
    }

    public static function paginateOrAll($query, $perPage = null)
    {
        $perPage = $perPage ?? \request('per_page', 10);

        return request('all', false) ? $query->get() : $query->paginate($perPage);
    }

    public static function paginateFromRequest($query, $perPage = 10)
    {
        return $query->paginate(request('per_page', $perPage));
    }

    public static function applyFilters($query)
    {
        static::searchFilters($query);
        static::dateFilter($query);
        static::sortBy($query);
    }
    public static function searchFilters($query, $paramsCount = 8, $prefix = '')
    {
        $prefix = empty($prefix) ? '' : $prefix . '.';
        for ($i = 1; $i <= $paramsCount; $i++) {
            $search = \request('search' . $i, false);
            $searchBy = \request('searchBy' . $i, false);
            if ($searchBy == 'category_id' && !empty($search)) {
                $query->whereHas('categoryPivot', function ($query2) use ($search) {
                    $query2->where('category_id', '=', $search);
                });

                return;
            }
            if(mb_strlen($search) > 0 && strlen($searchBy) > 0) {
                if(str_contains($searchBy, '_id')) {
                    $query->where($prefix . $searchBy, '=', $search);
                } else {
                    $query->where($prefix . $searchBy, 'LIKE', '%' . $search . '%');
                }
            }
        }
    }

    public static function dateFilter($builder)
    {
        $request = request();
        if($request->filled('start_date')) {
            $builder->where('created_at', '>', Carbon::createFromTimestamp($request->start_date));
        }
        if($request->filled('end_date')) {
            $builder->where('created_at', '<', Carbon::createFromTimestamp($request->end_date));
        }
    }

    public static function sortBy($builder)
    {
        if (request('sort', false)) {
            $order = 'asc';
            if(request('order', false) == 'desc')
            {
                $order = 'desc';
            }
            if (class_basename($builder) == 'Builder') {
                $builder->getQuery()->orders = null;
            } else {
                // is relationship
                $builder->getBaseQuery()->orders = null;
            }

            return $builder->orderBy(request('sort'), $order);
        }
    }

    public static function getIds($collection)
    {
        $ids = [];
        foreach ($collection as $item) {
            $ids[] = $item->id;
        }

        return $ids;
    }

    public static function getWhereInString(array $ids)
    {
        $queryString = ' ';
        foreach ($ids as $id) {
            $queryString .= $id . ',';
        }
        $queryString[strlen($queryString) - 1] = ' ';

        return $queryString;
    }

    public static function removeFromRequest(Request $request, ...$keys)
    {
        foreach ($keys as $key) {
            $jsonRequest = $request->json();
            $jsonRequest->remove($key);
            $request->request->remove($key);
        }
    }

    public static function makeValidationException($message, $key = 'unknown'): HttpResponseException
    {
        return new HttpResponseException(response()->error($message,
            [
                $key => [$message]
            ]
        , 422));
    }

    public static function getRealUrl()
    {
        return str_replace('api.', '', config('app.url'));
    }

    public static function getModelIdOnPut($model)
    {
        $model = request()->route($model);

        return is_object($model) ? $model->getKey() : $model;
    }

    // Return an object with only id and url
    public static function mediaToImage(?Media $media)
    {
        if (!$media) {
            return null;
        }
        $image = [];
        $image['id'] = $media->id;
        if (in_array($media->getExtensionAttribute(), ['docx', 'doc', 'ppt', 'txt', 'pptx', 'ppt'])) {
            $image['type'] = 'document';
        } else if (in_array($media->getExtensionAttribute(), ['zip', 'rar'])) {
            $image['type'] = 'archive';
        } else {
            $image['type'] = $media->type;
        }
        $image['url'] = $media->getUrl();

        return $image;
    }

    public static function mediasToImages(MediaCollection $mediaCollection)
    {
        $images = [];
        foreach ($mediaCollection as $media) {
            $images[] = Helpers::mediaToImage($media);
        }

        return $images;
    }

    /**
     * @param array $fields
     * @param $request
     * @return mixed
     */
    public static function toCarbonRequest(array $fields , $request): mixed
    {
        foreach ($fields as $field){
            if (is_numeric($field)) {
                $request->merge([$field => Carbon::createFromTimestamp($request->input($field))->toDateTimeString()]);
            } else {
                $request->merge([$field => Carbon::createFromTimestamp($request->input($field))->toDateTimeString()]);
            }
        }
        return $request;
    }

    public static function hideAttributes(\Traversable $models, ...$attributes)
    {
        foreach ($models as $model) {
            $model->makeHidden($attributes);
        }
    }

    public static function randomString()
    {
        return bcrypt(md5(md5(time().time())));
    }

    public static function unsetFillable($model, ...$keys)
    {
        $fillable = $model->fillable;
        foreach ($keys as $key) {
            unset($fillable[$key]);
        }
        $model->fillable($fillable);
    }

    public static function searchOnRelations($model , $field , string $q , $searchIn)
    {
        $query = $model->whereHas($searchIn, function ($query) use ($q , $field) {

            $query->where($field , 'like', "%$q%");

        });

        return $query;
    }

    /**
     * Get random numbers code.
     *
     * @param int $digits
     * @return int
     */
    public static function randomNumbersCode(int $digits = 4)
    {
        return rand(pow(10, $digits-1), pow(10, $digits) - 1);
    }

    public static function isStringBase64(string $value, string $mime = 'gif|png|jpg|jpeg|svg|webp'): bool
    {
        $base64RegEx = '#^data:image\/(?:'.$mime.')(?:;charset=utf-8)?;base64,.*+={0,2}#';
        if (!preg_match($base64RegEx, $value)){
            return false;
        }

        return true;
    }

    public static function decodeUnicode($str)
    {
        return preg_replace_callback('/\\\\u([0-9a-fA-F]{4})/', function ($match) {
            return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
        }, $str);
    }

    #[NoReturn] public static function checkResponseInTest($response)
    {
        dd(json_decode(Helpers::decodeUnicode($response->getContent())));
    }

    public static function hasCustomSearchBy($key)
    {
        for ($i = 1; $i < 99; $i++) {
            if (\request('searchBy' . $i) === $key && \request('search' . $i)) {
                $temp = \request('search' . $i);
                request()->merge(['search' . $i => null]);

                return $temp;
            }
        }

        return null;
    }

    public static function cacheRemember($key, $ttl, $callback)
    {
        return app()->environment('production') ? \Cache::remember($key, $ttl, $callback) : $callback();
    }

    public static function cacheForever($key, $callback)
    {
        return app()->environment('production') ? \Cache::rememberForever($key, $callback) : $callback();
    }

    public static function clearCacheInBooted($model, $key)
    {
        $key = is_array($key) ? $key : [$key];
        $model::updated(function () use ($key){
            \Cache::deleteMultiple($key);
        });
        $model::deleted(function () use ($key){
            \Cache::deleteMultiple($key);
        });
        $model::created(function () use ($key){
            \Cache::deleteMultiple($key);
        });
    }

    public static function convertFaNumbersToEn($string) {
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        $arabic = ['٩', '٨', '٧', '٦', '٥', '٤', '٣', '٢', '١','٠'];

        $num = range(0, 9);
        $convertedPersianNums = str_replace($persian, $num, $string);
        $englishNumbersOnly = str_replace($arabic, $num, $convertedPersianNums);

        return $englishNumbersOnly;
    }

    public static function setEventNameForLog($eventName): string
    {
        if ($eventName == 'updated'){
            return 'بروزرسانی';
        }
        if ($eventName == 'deleted'){
            return  'حذف';
        }
        if ($eventName == 'created'){
            return 'ایجاد';
        }
        return $eventName;
    }
}
