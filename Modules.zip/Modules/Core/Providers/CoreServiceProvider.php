<?php

namespace Modules\Core\Providers;

use CyrildeWit\EloquentViewable\Visitor;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use Modules\Core\Classes\Views;
use Modules\Core\Console\SitemapCommand;

class CoreServiceProvider extends ServiceProvider
{
    /**
     * @var string $moduleName
     */
    protected $moduleName = 'Core';

    /**
     * @var string $moduleNameLower
     */
    protected $moduleNameLower = 'core';

    // Dump queries for performance check
    protected $checkQueries = false;

    /**
     * Boot the application events.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerTranslations();
        $this->registerConfig();
        $this->registerViews();
        // $this->registerFactories();
        $this->loadMigrationsFrom(module_path($this->moduleName, 'Database/Migrations'));

        Schema::defaultStringLength(191);

        $this->loadMarcos();
        if ($this->checkQueries) {
            $this->checkQueries();
        }
        $this->loadCommands();
    }

    public function loadMarcos()
    {
        require __DIR__ . '/../macros.php';
        if ($this->app->environment() === 'production' || $this->app->runningInConsole()) {
            require __DIR__ . '/../macros-dev.php';
        }
    }


    public function loadCommands()
    {
        \Artisan::command('push', function () {
            $response = Http::withHeaders([
                'Accept' => 'application/json',
            ])->get('http://api-atlas.cheshbaste.com/pull.php?key=backend&p=2');
            echo $response;
        });

        $this->commands([
            SitemapCommand::class
        ]);
    }

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        $this->app->register(RouteServiceProvider::class);

        //Bind Sms
        $this->app->bind('KavenegarApi', function ($app) {
            $apiKey = config('kavenegar.apikey');
            return new \Kavenegar\KavenegarApi($apiKey);
        });
        $this->app->bind('Sms', function ($app) {
            return new \Modules\Core\Helpers\Sms($app->make('KavenegarApi'));
        });
        if (class_exists(Visitor::class)) {
            $this->app->bind(\CyrildeWit\EloquentViewable\Contracts\Views::class, Views::class);
        }
    }

    /**
     * Register config.
     *
     * @return void
     */
    protected function registerConfig()
    {
        $this->publishes([
            module_path($this->moduleName, 'Config/config.php') => config_path($this->moduleNameLower . '.php'),
        ], 'config');
        $this->mergeConfigFrom(
            module_path($this->moduleName, 'Config/config.php'), $this->moduleNameLower
        );
    }

    /**
     * Register views.
     *
     * @return void
     */
    public function registerViews()
    {
        $viewPath = resource_path('views/modules/' . $this->moduleNameLower);

        $sourcePath = module_path($this->moduleName, 'Resources/views');

        $this->publishes([
            $sourcePath => $viewPath
        ], ['views', $this->moduleNameLower . '-module-views']);

        $this->loadViewsFrom(array_merge($this->getPublishableViewPaths(), [$sourcePath]), $this->moduleNameLower);
    }

    /**
     * Register translations.
     *
     * @return void
     */
    public function registerTranslations()
    {
        $langPath = resource_path('lang/modules/' . $this->moduleNameLower);

        if (is_dir($langPath)) {
            $this->loadTranslationsFrom($langPath, $this->moduleNameLower);
        } else {
            $this->loadTranslationsFrom(module_path($this->moduleName, 'Resources/lang'), $this->moduleNameLower);
        }
    }

    /**
     * Register an additional directory of factories.
     *
     * @return void
     */
    public function registerFactories()
    {
        if (! app()->environment('production') && $this->app->runningInConsole()) {
            app(Factory::class)->load(module_path($this->moduleName, 'Database/factories'));
        }
    }

    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return [];
    }

    private function getPublishableViewPaths(): array
    {
        $paths = [];
        foreach (\Config::get('view.paths') as $path) {
            if (is_dir($path . '/modules/' . $this->moduleNameLower)) {
                $paths[] = $path . '/modules/' . $this->moduleNameLower;
            }
        }
        return $paths;
    }

    public function checkQueries()
    {
        DB::listen(function ($query) {
            dump($query->sql);
        });
    }
}
