<?php

namespace Modules\Core\Console;

use Illuminate\Console\Command;
use Illuminate\Routing\Route;
use Illuminate\Support\Str;
use Modules\Blog\Entities\Post;
use Modules\Category\Entities\Category;
use Modules\Product\Entities\Product;
use Spatie\Sitemap\Sitemap;
use Spatie\Sitemap\SitemapGenerator;
use Spatie\Sitemap\Tags\Url;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class SitemapCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sitemap:generate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate sitemap.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $url = config('app.front_url');
        $site_address = config('core.sitemap_address');
        $posts = Post::query()->select(['id', 'slug'])->get();
        $products = Product::query()->select(['id', 'title'])->get();
        $categories = Category::query()->select(['id', 'slug'])->get();

        $sitemap = Sitemap::create()
            ->add(Url::create('/')->setUrl($url.'/')->setLastModificationDate(now())->setPriority(1));

        foreach ($products as $product) {
            $sitemap->add(Url::create('/')->setUrl($url."/product/{$product->id}/{$product->slug}")->setLastModificationDate(now())->setPriority(1));
        }

        $sitemap->add(Url::create('/')->setUrl($url.'/weblog-list')->setLastModificationDate(now())->setPriority(0.5));
        foreach ($posts as $post) {
            $sitemap->add(Url::create("/")->setUrl($url."weblog-list/{$post->id}/{$post->slug}")
                ->setLastModificationDate(now())->setPriority(0.5));
        }

        $sitemap->add(Url::create('/')->setUrl($url.'/products')->setLastModificationDate(now())->setPriority(1))
        ->add(Url::create('/')->setUrl($url.'/products?sort=top_sales')->setLastModificationDate(now())->setPriority(0.8))
        ->add(Url::create('/')->setUrl($url.'/products?sort=low_to_high')->setLastModificationDate(now())->setPriority(0.8))
        ->add(Url::create('/')->setUrl($url.'/products?sort=most_visited')->setLastModificationDate(now())->setPriority(0.8))
        ->add(Url::create('/')->setUrl($url.'/products?sort=newest')->setLastModificationDate(now())->setPriority(0.8))
        ->add(Url::create('/')->setUrl($url.'/products?sort=most_discount')->setLastModificationDate(now())->setPriority(0.8));
        foreach ($categories as $category) {
            $sitemap->add(Url::create('/')->setUrl($url."/products/category/{$category->id}/{$category->slug}")
                ->setLastModificationDate(now())->setPriority(0.8));
        }

        $sitemap->writeToFile($site_address);
    }

    /**
     * Get the console command arguments.
     *
     * @return array
     */
    protected function getArguments()
    {
        return [
            ['example', InputArgument::REQUIRED, 'An example argument.'],
        ];
    }

    /**
     * Get the console command options.
     *
     * @return array
     */
    protected function getOptions()
    {
        return [
            ['example', null, InputOption::VALUE_OPTIONAL, 'An example option.', null],
        ];
    }
}
