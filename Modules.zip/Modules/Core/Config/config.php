<?php

return [
    'sitemap_address' => '/home/atlasmode/domains/atlasmode.ir/public_html/sitemap.xml'
];
