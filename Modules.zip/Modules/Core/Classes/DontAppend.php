<?php


namespace Modules\Core\Classes;


class DontAppend
{
    public function __construct(protected string $name)
    {
//        echo $name;
    }
}
