<?php


namespace Modules\Core\Services;


use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Modules\Product\Entities\Product;

class QueryFiltersService
{
    protected $query;
    protected $exactSearchFields;
    protected $prefix;

    public function __construct($query, $prefix, $exactSearchFields = [])
    {
        $this->query = $query;
        $this->exactSearchFields = $exactSearchFields;
    }

    public function applyAllFilters()
    {
        $this->searchFilters();
        $this->dateFilter();
        $this->sortFilter();
    }

    public function searchFilters($paramsCount = 8, $prefix = '')
    {
        $prefix = empty($prefix) ? '' : $prefix . '.';
        for ($i = 1; $i <= $paramsCount; $i++) {
            $search = \request('search' . $i, false);
            $searchBy = \request('searchBy' . $i, false);
            if (mb_strlen($search) > 0 && strlen($searchBy) > 0) {
                if (str_contains($searchBy, '_id') || in_array($searchBy, $this->exactSearchFields)) {
                    $this->query->where($prefix . $searchBy, '=', $search);
                } else {
                    $this->query->where($prefix . $searchBy, 'LIKE', '%' . $search . '%');
                }
            }
        }

        return $this->query;
    }

    public function dateFilter()
    {
        $request = request();
        if ($request->filled('start_date')) {
            $this->query->where('created_at', '>', Carbon::createFromTimestamp($request->start_date));
        }
        if ($request->filled('end_date')) {
            $this->query->where('created_at', '<', Carbon::createFromTimestamp($request->end_date));
        }

        return $this->query;
    }

    public function sortFilter()
    {
        if (request('sort', false)) {
            $order = 'asc';
            if(request('order', false) == 'desc')
            {
                $order = 'desc';
            }
            if (class_basename($this->query) == 'Builder') {
                $this->query->getQuery()->orders = null;
            } else {
                // is relationship
                $this->query->getBaseQuery()->orders = null;
            }

            return $this->query->orderBy(request('sort'), $order);
        }

        return $this->query;
    }
}
