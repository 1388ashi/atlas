<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Routing\ResponseFactory;
use Modules\Widget\Classes\Widget;

ResponseFactory::macro('success', function($message, array $data = null, $httpCode = 200) {
    Widget::appendRules($data);
    Widget::applyWidgets($data);

    return response()->json([
        'success' => true,
        'message' => $message,
        'data' => $data,
    ], $httpCode);
});

ResponseFactory::macro('error', function($message, array $data = null, $httpCode = 400) {
    if ($httpCode == 422) {
        return response()->json([
            'success' => false,
            'message' => $message,
            'errors' => $data,
        ], $httpCode);
    }

    return response()->json([
        'success' => false,
        'message' => $message,
        'data' => $data,
    ], $httpCode);
});

//\Route::macro('superGroup', function ($model, $middlewares = []) {
//    $this->prefix($model)->name($model . '.')->namespace(ucfirst($model));
//    if (empty($middlewares)) {
//        $middlewares[] = 'auth:' . $model . '-api';
//    }
//    $this->middleware($middlewares);
//
//    return $this;
//});
