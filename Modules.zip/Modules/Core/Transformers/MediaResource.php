<?php

namespace Modules\Core\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;

class MediaResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        try {
            $this->getExtensionAttribute();
        } catch (\Error $exception) {
            // یعنی عکس نداره
            return null;
        }
        if (in_array($this->getExtensionAttribute(), ['docx', 'doc', 'ppt', 'txt', 'pptx', 'ppt'])) {
            $type = 'document';
        } else if (in_array($this->getExtensionAttribute(), ['zip', 'rar'])) {
            $type = 'archive';
        } else {
            $type = $this->type;
        }
        $conversions = [];
//        foreach ($this->getGeneratedConversions() as $conversion => $active) {
//            if ($active) {
//                $conversions[$conversion] = $this->getUrl($conversion);
//            } else {
//                $conversions[$conversion] = $this->getUrl();
//            }
//        }

        return [
            'id' => $this->id,
            'type' => $type,
            'url' => $this->getUrl(),
//            'conversions' => $conversions,
//            'srcset' => $this->getSrcSetArray(),
//            'placeholder' => $this->getSvgPlaceholder()
        ];
    }
}
