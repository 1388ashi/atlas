<?php


namespace Modules\Core\Traits;


trait HasViews
{
    public function record()
    {
        if (\DB::table('model_views')->where('model_id', $this->id)
            ->where('model_type', $this->getMorphClass())->exists()) {
            \DB::table('model_views')->where('model_id', $this->id)
                ->where('model_type', $this->getMorphClass())->update([
                    'count' => \DB::raw('count + 1'),
                    'updated_at' => now()
                ]);
        } else {
            \DB::table('model_views')->insert([
                'model_id' => $this->id,
                'model_type' => $this->getMorphClass(),
                'count' => 1,
                'created_at' => now(),
                'updated_at' => now()
            ]);
        }
    }
}
