<?php


namespace Modules\Core\Http\Controllers;


use App\Http\Controllers\Controller;

abstract class BaseController extends Controller
{

}
