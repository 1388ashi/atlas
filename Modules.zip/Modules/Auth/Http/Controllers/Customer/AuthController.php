<?php

namespace Modules\Auth\Http\Controllers\Customer;

use Auth;
use Carbon\Carbon;
use Exception;
use Hash;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Validation\ValidationException;
use Laravel\Sanctum\Sanctum;
use Log;
use Modules\Auth\Http\Requests\Customer\CustomerForgetPasswordRequest;
use Modules\Auth\Http\Requests\Customer\CustomerLoginRequest;
use Modules\Auth\Http\Requests\Customer\CustomerRegisterLoginRequest;
use Modules\Auth\Http\Requests\Customer\CustomerRegisterRequest;
use Modules\Auth\Http\Requests\Customer\CustomerResetPasswordRequest;
use Modules\Auth\Http\Requests\Customer\CustomerSendTokenRequest;
use Modules\Auth\Http\Requests\Customer\CustomerVerifyRequest;
use Modules\Cart\Classes\CartFromRequest;
use Modules\Core\Entities\User;
use Modules\Core\Services\NotificationService;
use Modules\Customer\Entities\Customer;
use Modules\Customer\Entities\SmsToken;
use Modules\Customer\Events\SmsVerify;

class AuthController extends Controller
{
    public function registerLogin(CustomerRegisterLoginRequest $request): JsonResponse
    {
        try {
            $customer = Customer::where('mobile', $request->mobile)->first(['id']);
            $status = $customer ? 'login' : 'register';

            if ($status === 'register') {
                $result = event(new SmsVerify($request->mobile));
                if (!$result[0]['success']) {
                    throw new Exception($result[0]['message']);
                }
            }

            $mobile = $request->mobile;

            return response()->success('بررسی وضعیت ثبت نام مشتری', compact('status', 'mobile'));
        } catch(Exception $exception) {
            return response()->error(
                'مشکلی در برنامه بوجود آمده است. لطفا با پشتیبانی تماس بگیرید: ' . $exception->getMessage(),
                [],
                500
            );
        }
    }

    public function sendToken(CustomerSendTokenRequest $request): JsonResponse
    {
        try {
            $result = event(new SmsVerify($request->mobile));
            if (!$result[0]['success']) {
                throw new Exception($result[0]['message']);
            }
            $mobile = $request->mobile;
            return response()->success('بررسی وضعیت ثبت نام مشتری', compact('mobile'));
        } catch(Exception $exception) {
            return response()->error(
                'مشکلی در برنامه بوجود آمده است. لطفا با پشتیبانی تماس بگیرید: ' . $exception->getMessage(),
                [],
                500
            );
        }
    }

    public function verify(CustomerVerifyRequest $request): JsonResponse
    {
        try {
            $request->smsToken->verified_at = now();
            $request->smsToken->save();
            $data['mobile'] = $request->mobile;

            if ($request->type === 'login') {
                $customer = $request->customer;
                $customer->load(['listenCharges', 'carts' => function ($query) {
                    $query->withCommonRelations();
                }]);
                $token = $customer->createToken('authToken')->plainTextToken;
                $data['access_token'] = $token;
                $data['user'] = $customer;
                $data['token_type'] = 'Bearer';
                $notificationService = new NotificationService($customer);
                $data['notifications'] = [
                    'items' => $notificationService->get(),
                    'total_unread' => $notificationService->getTotalUnread()
                ];
                Sanctum::actingAs($customer);
                $warnings = CartFromRequest::addToCartFromRequest($request);
                $data['cart_warnings'] = $warnings;
                $data['carts'] = $customer->carts()->withCommonRelations()->get();
                $customer->loadCommonRelations();
            }

            return response()->success('', compact('data'));
        } catch(Exception $exception) {
            return response()->error(
                'مشکلی در برنامه بوجود آمده است. لطفا با پشتیبانی تماس بگیرید: ' . $exception->getMessage(),
                [],
                500
            );
        }
    }

    public function register(CustomerRegisterRequest $request): JsonResponse
    {
        $customer = Customer::create($request->all());
        $customer->load(['listenCharges', 'carts' => function ($query) {
            $query->withCommonRelations();
        }]);

        $token = $customer->createToken('authToken')->plainTextToken;
        Sanctum::actingAs($customer);
        $warnings = CartFromRequest::addToCartFromRequest($request);
        $customer->loadCommonRelations();
        $notificationService = new NotificationService($customer);
        $data = [
            'access_token' => $token,
            'token_type' => 'Bearer',
            'cart_warnings' => $warnings,
            'user' => $customer,
            'carts' => $customer->carts()->withCommonRelations()->get(),
            'notifications' => [
                'items' => $notificationService->get(),
                'total_unread' => $notificationService->getTotalUnread()
            ]
        ];

        return response()->success('ثبت نام با موفقیت انجام شد', compact('data'));
    }

    public function login(CustomerLoginRequest $request): JsonResponse
    {
        $customer = $request->customer;

        if (! $customer || ! Hash::check($request->password, $customer->password)) {
            return response()->error('اطلاعات وارد شده اشتباه است.', [], 401);
        }

        $customer->load(['listenCharges', 'carts' => function ($query) {
            $query->withCommonRelations();
        }]);
        $token = $customer->createToken('authToken');
        $token->accessToken->device_token = $request->device_token;
        $token->accessToken->save();
        // اون ایدی کارت هایی که ساخته شده در کوکی رو تو دیتابیس میزاره
        Sanctum::actingAs($customer);
        $warnings = CartFromRequest::addToCartFromRequest($request);
        $customer->loadCommonRelations();
        $notificationService = new NotificationService($customer);

        $data = [
            'user' => $customer,
            'access_token' => $token->plainTextToken,
            'token_type' => 'Bearer',
            'cart_warnings' => $warnings,
            'carts' => $customer->carts()->withCommonRelations()->get(),
            'notifications' => [
                'items' => $notificationService->get(),
                'total_unread' => $notificationService->getTotalUnread()
            ]
        ];

        return response()->success('کاربر با موفقیت وارد شد.', compact('data'));

    }

    public function logout(Request $request): JsonResponse
    {
        /**
         * @var $user Customer
         */
        $user = $request->user();
        $user->currentAccessToken()->delete();

        return response()->success('خروج با موفقیت انجام شد');
    }

    public function resetPassword(CustomerResetPasswordRequest $request): JsonResponse
    {
        $customer = $request->customer;
        $customer->update($request->only('password'));

        Sanctum::actingAs($customer);
        $warnings = CartFromRequest::addToCartFromRequest($request);
        $customer->loadCommonRelations();

        $token = $customer->createToken('authToken')->plainTextToken;
        $customer->load(['listenCharges']);

        $notificationService = new NotificationService($customer);

        $data = [
            'user' => $customer,
            'access_token' => $token,
            'token_type' => 'Bearer',
            'cart_warnings' => $warnings,
            'carts' => $customer->carts()->withCommonRelations()->get(),
            'notifications' => [
                'items' => $notificationService->get(),
                'total_unread' => $notificationService->getTotalUnread()
            ]
        ];

        return response()->success('', compact('data'));
    }

    public function setDeviceToken(Request $request)
    {
        /**
         * @var $user Customer
         */
        $user = auth()->user();
        $accessToken = $user->currentAccessToken();
        $accessToken->device_token = $request->device_token;
        $accessToken->save();
    }
}
