<?php

namespace Modules\Auth\Http\Controllers\Admin;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Modules\Admin\Entities\Admin;
use Modules\Auth\Http\Requests\Admin\AdminLoginRequest;

class AuthController extends Controller
{
    /**
     * Display a listing of the resource.
     * @param AdminloginRequest $request
     * @return mixed
     */
    public function login(AdminLoginRequest   $request)
    {
        $admin = Admin::whereUsername($request->username)->first();

        if (!$admin || !Hash::check($request->password, $admin->password)){
            return response()->error('نام کاربری یا رمز عبور اشتباه است');
        }
        $token = $admin->createToken('Admin Login')->plainTextToken;

        return response()->success('ورود با موفقیت انجام شد', compact('token'));
    }

    public function logout(Request $request)
    {
        auth()->user()->currentAccessToken()->delete();

        return response()->success('خروج با موفقیت انجام شد');
    }

}
