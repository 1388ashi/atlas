<?php
namespace Modules\Area\Entities;

use Modules\Area\Entities\City;
use Modules\Core\Entities\BaseModel;
use Modules\Core\Entities\HasCommonRelations;
use Modules\Shipping\Entities\Shipping;

class Province extends BaseModel
{
    use HasCommonRelations;

    protected $fillable = ['name', 'status'];


	public function cities(): \Illuminate\Database\Eloquent\Relations\HasMany
	{
		return $this->hasMany(City::class);
	}

    public function shippings()
    {
        return $this->morphToMany(Shipping::class, 'shippable');
	}

    public function scopeActive($query)
    {
        $query->where('status', true);
	}
}
