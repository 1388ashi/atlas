<?php
namespace Modules\Area\Entities;

use Illuminate\Database\Eloquent\Model;
use Modules\Core\Entities\BaseModel;
use Modules\Core\Entities\HasCommonRelations;
use Modules\Shipping\Entities\Shipping;

class City extends BaseModel
{
	use HasCommonRelations;

	protected static $commonRelations = ['province'];

    protected $fillable = ['name', 'province_id', 'status'];


	public function province(): \Illuminate\Database\Eloquent\Relations\BelongsTo
	{
		return $this->belongsTo(Province::class);
	}

    public function shippings()
    {
        return $this->morphToMany(Shipping::class, 'shippable');
    }

    public function scopeActive($query)
    {
        $query->where('status', true);
    }
}
