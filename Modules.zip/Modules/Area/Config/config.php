<?php

return [
    'name' => 'Area'
];
