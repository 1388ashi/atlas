<?php


namespace Modules\Area\Http\Controllers;


use Modules\Area\Entities\City;
use Modules\Area\Entities\Province;

class AreaController
{
    public function index()
    {
        $provinces = Province::latest('id', 'name')->active()->select('id', 'name')->with(['cities' => function($query) {
            $query->select('id', 'name', 'province_id');
            $query->active();
        }])->select()->get();

        return response()->success('', compact('provinces'));
    }
}
