<?php
namespace Modules\Area\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Modules\Area\Entities\City;
use Modules\Area\Entities\Province;
use Modules\Area\Http\Requests\Admin\CityStoreRequest;
use Modules\Area\Http\Requests\Admin\CityUpdateRequest;

class CityController extends Controller
{
	public function index()
	{
		$cities = City::latest()->filters()->withCommonRelations()->paginateOrAll();

		return response()->success('', compact('cities'));
	}


	public function show(Int $id)
	{
		$city = City::withCommonRelations()->findOrFail($id);

		return response()->success('', compact('city'));
	}


    /**
     * Store a newly created resource in storage
     * @param CityStoreRequest $request
     * @return JsonResponse
     */
	public function store(CityStoreRequest $request)
	{
		$city = new City();
		$city->fill($request->all());
		$city->province()->associate($request->province_id);
		$city->save();
		$city->loadCommonRelations();

		return response()->success('شهر با موفقیت ایجاد شد', compact('city'));
	}


    /**
     * Update the specified resource in storage.
     * @param CityUpdateRequest $request
     * @param int $id
     * @return JsonResponse
     */
	public function update(CityUpdateRequest $request, Int $id)
	{
		$city = City::query()->findOrFail($id);
		$province = Province::query()->findOrFail($request->province_id);
		$city->province()->associate($province);
		$city->fill($request->all());
		$city->save();

		return response()->success('شهر با موفقیت بروز شد', compact('city'));
	}

	public function destroy(Int $id)
	{
		$city = City::destroy($id);

		return response()->success('شهر با موفیت حذف شد', compact('city'));
	}
}
