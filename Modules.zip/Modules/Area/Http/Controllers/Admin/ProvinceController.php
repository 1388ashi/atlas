<?php
namespace Modules\Area\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Area\Entities\City;
use Modules\Area\Entities\Province;
use Modules\Area\Http\Requests\Admin\ProvinceStoreRequest;
use Modules\Area\Http\Requests\Admin\ProvinceUpdateRequest;

class ProvinceController extends Controller
{
	public function index()
	{
		$provinces = Province::withCommonRelations()->filters()->latest()->paginateOrAll();

		return response()->success('', compact('provinces'));
	}


	public function show(Int $id)
	{
		$province = Province::withCommonRelations()->findOrFail($id);

		return response()->success('', compact('province'));
	}


    /**
     * Store a newly created resource in storage
     * @param ProvinceStoreRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
	public function store(ProvinceStoreRequest $request)
	{
		$province = new Province();
		$province->fill($request->all());
		$province->save();

		return response()->success('استان با موفقیت ایجاد شد', compact('province'));
	}


    /**
     * Update the specified resource in storage.
     * @param ProvinceUpdateRequest $request
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
	public function update(ProvinceUpdateRequest $request, Int $id)
	{
		$province = Province::query()->findOrFail($id);
		$province->fill($request->all());
		$province->save();

		return response()->success('استان با موفقیت بروز شد', compact('province'));
	}


	public function destroy(Int $id)
	{
		$province = Province::destroy($id);

		return response()->success('استان با موفقیت حذف شد', compact('province'));
	}
}
