<?php

namespace Modules\Advertise\Http\Controllers\Admin;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Advertise\Entities\PositionAdvertise;
use Modules\Advertise\Http\Requests\Position\PositionStoreRequest;
use Modules\Advertise\Http\Requests\Position\PositionUpdateRequest;
use Modules\Core\Helpers\Helpers;

class PositionAdvertiseController extends Controller
{
    public function index()
    {
        $positionAdvertiseBuilder = PositionAdvertise::with('advertisements');
        Helpers::applyFilters($positionAdvertiseBuilder);
        $positions = Helpers::paginateOrAll($positionAdvertiseBuilder);

        return response()->success('' , compact('positions'));
    }

    public function show($id)
    {
        $positions = PositionAdvertise::with('advertisements')->findOrFail($id);

        return response()->success('' , compact('positions'));
    }

    public function store(PositionStoreRequest $request)
    {
        $positionAdvertise = PositionAdvertise::create($request->all());
        $positionAdvertise->load('advertisements');

        return response()->success('جایگاه با موفقیت اضافه شد', compact('positionAdvertise'));
    }

    public function update(PositionUpdateRequest $request, $positionAdvertiseId)
    {
        $positionAdvertise = PositionAdvertise::findOrFail($positionAdvertiseId);
        $positionAdvertise->update($request->all());
        $positionAdvertise->load('advertisements');

        return response()->success('جایگاه با موفقیت ویرایش شد', compact('positionAdvertise'));
    }
}
