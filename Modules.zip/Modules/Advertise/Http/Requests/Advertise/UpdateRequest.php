<?php

namespace Modules\Advertise\Http\Requests\Advertise;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Modules\Core\Helpers\Helpers;
use Modules\Link\Services\LinkValidator;

class UpdateRequest extends FormRequest
{


    public function rules()
    {
        return [
            'image' => 'nullable|mimes:jpg,jpeg,png',
            'link' => "nullable|string",
            'new_tab' => 'required|in:0,1',
            'start' => 'required',
            'end' => 'required',
        ];
    }

    public function passedValidation()
    {
        (new LinkValidator($this))->validate();
    }
}
