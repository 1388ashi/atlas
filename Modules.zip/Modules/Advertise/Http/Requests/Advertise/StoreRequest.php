<?php

namespace Modules\Advertise\Http\Requests\Advertise;

use Illuminate\Foundation\Http\FormRequest;
use Modules\Core\Helpers\Helpers;
use Modules\Link\Services\LinkValidator;
use Modules\Menu\Entities\MenuItem;

class StoreRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'image' => 'required|mimes:jpg,jpeg,png',
            'link' => "nullable|string",
            'new_tab' => 'required|in:0,1',
            'start' => 'required',
            'end' => 'required',
        ];
    }

    public function passedValidation()
    {
        (new LinkValidator($this))->validate();
    }
}
