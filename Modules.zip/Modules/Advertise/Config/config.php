<?php

return [
    'name' => 'Advertise'
];
