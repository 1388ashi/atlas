<?php

namespace Modules\Home\Http\Controllers;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Laravel\Sanctum\Sanctum;
use Modules\Advertise\Entities\Advertise;
use Modules\Advertise\Http\Controllers\All\AdvertiseController;
use Modules\Attribute\Entities\Attribute;
use Modules\Blog\Entities\Post;
use Modules\Cart\Classes\CartFromRequest;
use Modules\Category\Entities\Category;
use Modules\Core\Helpers\Helpers;
use Modules\Core\Services\NotificationService;
use Modules\Customer\Entities\Customer;
use Modules\Flash\Entities\Flash;
use Modules\Instagram\Entities\Instagram;
use Modules\Menu\Entities\MenuItem;
use Modules\Product\Entities\Product;
use Modules\Setting\Entities\Setting;
use Modules\Slider\Entities\Slider;

class HomeController extends Controller
{

    public function index(Request $request)
    {
        /**
         * @var $user Customer
         * @var $products Collection
         */
        $products = Product::query()->with(['categories', 'activeFlash', 'varieties', 'varietyOnlyDiscountsRelationship'])
            ->active('=', Product::STATUS_AVAILABLE)->latest()->get();

        $user = \Auth::guard('customer-api')->user();
        if ($user) {
            $user->load('listenCharges');
        }

        $menu = Helpers::cacheForever('home_menu', function (){
            return MenuItem::query()->active()->with('children', 'group')->get()->groupBy('group.title');
        });
        $post = Helpers::cacheRemember('home_post', 120, function (){
            return Post::query()->published()->latest('id')->take(4)->get();
        });
        $slider = Helpers::cacheForever('home_slider', function (){
            return Slider::query()->active()->get();
        });
        $flashes = Helpers::cacheRemember('home_flash', 60, function (){
            return Flash::query()->active()->with(['products.varieties'])->get();
        });
        $settings = Helpers::cacheForever('settings', function (){
            return Setting::query()->where('private', 0)->get();
        });
        $advertise = Advertise::getForHome();
        $special_categories = Helpers::cacheForever('home_special_category', function (){
            return Category::query()->with('children')->take(8)
                ->parents()->special()->active()->latest()->get();
        });

        $categories = Helpers::cacheForever('home_category', function (){
            return Category::query()->with('children')->active()->parents()->get();
        });

        $suggestions = Helpers::cacheRemember('product_suggestion_' . \Auth::id(), 60, function () use ($products) {
            return $products->take(10);
        });

        $mostSales =  Helpers::cacheRemember('home_most_sales', 300, function () use ($products){
            return array_values($products->append('total_sales')
                ->sortBy('total_sales')->take(10)->toArray());
        });

        $mostDiscount = Helpers::cacheRemember('home_most_discount', 60, function () use ($products){
            $catIds = \DB::table('model_views')->orderBy('count')
                ->take(5)->get('model_id')->pluck('model_id')->toArray();
            return Product::query()
                ->with(['categories', 'activeFlash', 'varieties','varietyOnlyDiscountsRelationship'])
                ->active('=', Product::STATUS_AVAILABLE)
                ->whereHas('categories' ,function ($query) use ($catIds){
                    $query->whereIn('id', $catIds);
                })->latest()->take(10)->get()->toArray();
       });

        // توی فیلتر محصولات نیاز داریم سایز هم داشته باشیم
        $sizeValues = Helpers::cacheRemember('size_values', 3600, function () use ($products){
            $sizeAttribute = Attribute::whereName('size')->select('id')->first();
            if (!$sizeAttribute) {
                return [];
            }

            return [
                'id' => $sizeAttribute->id,
                'values' => $sizeAttribute->values()->select(['id', 'value'])->get()
            ];
        });

        $instagram = Instagram::getInstagramPosts();
        $notificationService = $user == null ? null : new NotificationService($user);
        $user = [
            'user' => ($user == null) ? false : $user->loadCommonRelations(),
            'device_token' => ($user == null) ? false : $user->currentAccessToken()->device_token,
            'login' => !(($user == null)),
            'cart' => ($user ==  null) ? null : $user->carts()->withCommonRelations()->get(),
            'notifications' => ($user == null) ? null : [
                'items' => $notificationService->get(),
                'total_unread' => $notificationService->getTotalUnread()
            ]
        ];


        // دادن کارت های مجازی(کوکی)
        $cartFromRequestResult = CartFromRequest::checkCart($request);

        $response = [
            'user'      => $user,
            'menu'      => $menu,
            'post'      => $post,
            'sliders'   => $slider,
            'flashes'   => $flashes,
            'mostSales'=> $mostSales,
            'settings'  => $settings,
            'advertise' => $advertise,
            'instagram' => $instagram,
            'categories'=> $categories,
            'suggestions'=> $suggestions,
            'mostDiscount'=> $mostDiscount,
            'special_categories'=> $special_categories,
            'cart_request' => $cartFromRequestResult,
            'size_values' => $sizeValues
        ];

        return response()->success(':)', compact('response'));
    }
}
