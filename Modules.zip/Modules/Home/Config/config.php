<?php

return [
    'name' => 'Home'
];
