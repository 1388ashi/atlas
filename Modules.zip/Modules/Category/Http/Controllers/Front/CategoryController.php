<?php

namespace Modules\Category\Http\Controllers\Front;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Category\Entities\Category;
use Modules\Category\Http\Requests\Admin\CategorySortRequest;
use Modules\Category\Http\Requests\Admin\CategoryStoreRequest;
use Modules\Category\Http\Requests\Admin\CategoryUpdateRequest;
use Modules\Core\Helpers\Helpers;

class CategoryController extends Controller
{

    public function index()
    {
        $categories = Category::query()->active()->parents()->with('children')
            ->orderBy('priority', 'DESC')
            ->filters()->paginateOrAll();

        return  response()->success('تمام دسته بندی ها', compact('categories'));
    }

    public function show($id)
    {
        $category = Category::query()->with('products')->findOrFail($id);

        return response()->success('', compact('category'));
    }
}
