<?php

namespace Modules\Category\Http\Controllers\Admin;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Cache;
use Modules\Category\Entities\Category;
use Modules\Category\Http\Requests\Admin\CategorySortRequest;
use Modules\Category\Http\Requests\Admin\CategoryStoreRequest;
use Modules\Category\Http\Requests\Admin\CategoryUpdateRequest;
use Modules\Core\Helpers\Helpers;

class CategoryController extends Controller
{

    public function index()
    {
        $categories = Category::withCommonRelations()->parents()->orderBy('priority', 'DESC')->filters();
        if (\request('all')) {
            $categories->with('children');
        }
        $categories = $categories->paginateOrAll();

        return  response()->success('تمام دسته بندی ها', compact('categories'));
    }

    public function indexLittle()
    {
        $categories = Category::without('media')->parents()->orderBy('priority', 'DESC')->filters();
        if (\request('all')) {
            $categories->with('children');
        }
        $categories = $categories->paginateOrAll();

        return  response()->success('تمام دسته بندی ها', compact('categories'));
    }

    public function store(CategoryStoreRequest $request , Category $category)
    {
        $category->fill($request->all());

        if($request->parent_id != null){
            $findParent = Category::query()->find($request->parent_id);
            $category->level = $findParent->level + 1 ;
        }
        $category->save();
        $category->attributes()->attach($request->attribute_ids);
        $category->specifications()->attach($request->specification_ids);
        $category->brands()->attach($request->brand_ids);
        $category->loadCommonRelations();

       if ($request->hasFile('image')) {
           $category->addImage($request->file('image'));
       }
       if ($request->hasFile('icon')) {
           $category->addIcon($request->file('icon'));
       }

        return response()->success('دسته بندی با موفقیت ایجاد شد.', compact('category'));
    }

    public function sort(CategorySortRequest $request)
    {
        Category::sort($request->input('categories'));
        Cache::deleteMultiple(['home_special_category', 'home_category']);

        return response()->success('مرتب سازی با موفقیت انجام شد');
    }

    public function show($id)
    {
        $category = Category::query()->withCommonRelations()->find($id);

        return response()->success('', compact('category'));
    }

    public function update(CategoryUpdateRequest $request, $id)
    {
        $category = Category::query()->find($id);
        $category->fill($request->validated());
        if ($request->hasFile('image')) {
            $category->addImage($request->image);
        }
        if ($request->hasFile('icon')) {
            $category->addIcon($request->icon);
        }

        $category->attributes()->sync($request->attribute_ids);
        $category->specifications()->sync($request->specification_ids);
        $category->brands()->sync($request->brand_ids);

        $category->save();
        $category->loadCommonRelations();

        return response()->success('دسته بندی با موفقیت بروزرسانی شد', compact('category'));
    }


    public function destroy($id)
    {
        $category = Category::query()->findOrFail($id);
        $category->delete();

        return response()->success('دسته بندی با موفقیت حذف شد', compact('category'));
    }
}
