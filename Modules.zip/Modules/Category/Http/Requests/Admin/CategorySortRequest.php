<?php

namespace Modules\Category\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Modules\Brand\Entities\Brand;
use Modules\Category\Http\Controllers\Admin\CategoryController;
use Modules\Core\Helpers\Helpers;
use Modules\Category\Entities\Category;


class CategorySortRequest extends FormRequest
{
    public function rules()
    {
        return [
            'categories' => 'required|array',
        ];
    }

    protected function passedValidation()
    {

    }
}
