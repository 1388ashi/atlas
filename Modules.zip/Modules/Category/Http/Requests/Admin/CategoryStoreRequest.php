<?php

namespace Modules\Category\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Modules\Category\Entities\Category;

class CategoryStoreRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'             => 'required|string|min:1|unique:categories,title' ,
            'en_title'          => 'nullable|string|min:1|unique:categories,en_title' ,
            'description'       => 'nullable|string' ,
            'parent_id'         => 'nullable|exists:categories,id' ,
            'status'            => 'required|boolean' ,
            'special'           => 'required|boolean' ,
            'meta_title'        => 'nullable|string' ,
            'meta_description'  => 'nullable|string' ,
            'attribute_ids'     => 'nullable|array',
            'attribute_ids.*'   => 'exists:attributes,id',
            'brand_ids'         => 'nullable|array',
            'brand_ids.*'       => 'exists:brands,id',
            'specification_ids' => 'nullable|array',
            'specification_ids.*' =>'exists:specifications,id',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function passedValidation()
    {

    }

}
