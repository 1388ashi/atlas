<?php

namespace Modules\Category\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Modules\Category\Entities\Category;
use Modules\Core\Helpers\Helpers;

class CategoryUpdateRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $title = Helpers::getModelIdOnPut('category');
        return [
            'title'                => 'required|string|min:1|unique:categories,title,' . $title ,
            'en_title'             => 'nullable|string|min:1|unique:categories,en_title,' . $title ,
            'description'          => 'nullable|string' ,
            'parent_id'            => 'nullable|exists:categories,id' ,
            'status'               => 'required|boolean' ,
            'special'              => 'required|boolean' ,
            'meta_title'           => 'nullable|string' ,
            'meta_description'     => 'nullable|string' ,
            'attribute_ids'        => 'nullable|array',
            'attribute_ids.*'      => 'exists:attributes,id',
            'brand_ids'            => 'nullable|array',
            'brand_ids.*'          => 'exists:brands,id',
            'specification_ids' => 'nullable|array',
            'specification_ids.*' =>'exists:specifications,id',
        ];
    }

    public function passedValidation()
    {
        if ($this->input('parent_id')) {
            $parentCategory = Category::findOrFail($this->input('parent_id'));
            $categoryId = Helpers::getModelIdOnPut('category');
            if (!$categoryId) {
                return;
            }
            if ($parentCategory->id == $categoryId) {
                throw Helpers::makeValidationException('خودش نمیتونه پدر خودش باشه !');
            }
            if ($parentCategory->parent_id == $categoryId) {
                throw Helpers::makeValidationException('نمیشه هردو پدر هم باشن !');
            }
            // جلوگیری از لوپ بینهایت
            $parentId = $parentCategory->parent_id;
            while ($parentId != null) {
                $tempMenu = Category::find($parentId);
                if (!$tempMenu) {
                    continue;
                }
                if ($tempMenu->parent_id == $categoryId) {
                    throw Helpers::makeValidationException('انتخاب پدر از نوه نتیجه نبیره و ... مجاز نیست');
                }
                $parentId = $tempMenu->parent_id;
            }
        }
    }
}
