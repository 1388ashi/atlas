<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCategoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('title')->unique();
            $table->string('slug');
            $table->string('en_title')->nullable()->unique();
            $table->text('description')->nullable();
            // Image in spatie library
            // Icon in spatie library
            $table->foreignId('parent_id')->nullable()->constrained('categories');
            $table->boolean('status');
            $table->boolean('special');
            $table->string('meta_title')->nullable();
            $table->text('meta_description')->nullable();
            $table->unsignedBigInteger('priority')->index();
            $table->unsignedBigInteger('level');
            $table->unsignedBigInteger('order')->default(1);
            $table->authors();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('categories');
    }
}
