<?php
namespace Modules\Category\Database\factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Modules\Category\Entities\Category;

class CategoryFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = \Modules\Category\Entities\Category::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'title' => $this->faker->realText(15),
            'description' => $this->faker->realText(),
            'parent_id' => null,
//            'parent_id' => $this->faker->randomElement([Category::factory()->count(1)->create()->id, null, null, null, null, null, null]),
            'status' => 1,
            'special' => 1,
            'meta_title' => $this->faker->title(),
            'meta_description' => $this->faker->realText(80),
            'priority' => 99999,
            'level' => 1,
        ];
    }

}

