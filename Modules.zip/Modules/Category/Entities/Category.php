<?php

namespace Modules\Category\Entities;

use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Http\Request;
use Modules\Attribute\Entities\Attribute;
use Modules\Brand\Entities\Brand;
use Modules\Category\Database\factories\CategoryFactory;
use Modules\Core\Classes\DontAppend;
use Modules\Core\Entities\BaseModel;
use Modules\Core\Entities\HasCommonRelations;
use Modules\Core\Helpers\Helpers;
use Modules\Core\Traits\HasAuthors;
use Modules\Core\Traits\HasDefaultFields;
use Modules\Core\Traits\HasStatus;
use Modules\Core\Traits\HasViews;
use Modules\Core\Transformers\MediaResource;
use Modules\Product\Entities\Product;
use Modules\Specification\Entities\Specification;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\EloquentSortable\SortableTrait;
use Spatie\MediaLibrary\HasMedia;
use Modules\Core\Traits\InteractsWithMedia;


class Category extends BaseModel implements HasMedia
{
    use InteractsWithMedia, HasDefaultFields, HasAuthors, LogsActivity,
        SortableTrait, HasFactory, HasCommonRelations, HasViews, Sluggable;

    public $sortable = [
        'order_column_name' => 'order',
        'sort_when_creating' => true,
    ];

    protected $fillable = [
        'title',
        'en_title',
        'description',
        'parent_id',
        'status',
        'special',
        'meta_title',
        'meta_description',
        'priority',
        'level'
    ];

    protected $defaults = [
        'special' => true,
        'status' => true,
        'priority' => 1,
        'level' => 1
    ];

    protected $cast = ['priority' => 'int' ];

    protected $appends = ['image', 'icon'];

    protected $withCount = ['products'];

    protected $hidden = ['media'];

    protected static $commonRelations = ['children', 'attributes', 'specifications', 'brands', 'products'];

    protected static function newFactory()
    {
        return CategoryFactory::new();
    }

    protected static function booted()
    {
        parent::booted();
        static::deleting(function ($category){
            if ($category->products()->exists()){
               throw Helpers::makeValidationException('دسته بندی دارای محصول میباشد.');
            }
        });
        Helpers::clearCacheInBooted(static::class, 'home_category');
        Helpers::clearCacheInBooted(static::class, 'home_special_category');
    }

    public function getActivitylogOptions(): LogOptions
    {
        $admin = \Auth::user();
        $name = !is_null($admin->name) ? $admin->name : $admin->username;
        return LogOptions::defaults()
            ->useLogName('Category')->logAll()->logOnlyDirty()
            ->setDescriptionForEvent(function($eventName) use ($name){
                $eventName = Helpers::setEventNameForLog($eventName);
                return "دسته بندی {$this->title} توسط ادمین {$name} {$eventName} شد";
            });
    }

    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'title'
            ]
        ];
    }

    public function parent(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Category::class, 'parent_id');
    }

    public function children(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Category::class , 'parent_id' , 'id')
            ->orderBy('priority', 'DESC')
            ->with(['children', 'attributes.values', 'brands', 'specifications.values']);
    }

    public function attributes(): \Illuminate\Database\Eloquent\Relations\BelongsToMany
    {
        return $this->belongsToMany(Attribute::class)->withTimestamps();
    }

    public function specifications(): \Illuminate\Database\Eloquent\Relations\BelongsToMany
     {
        return $this->belongsToMany(Specification::class)->withTimestamps();
    }

    public function brands(): \Illuminate\Database\Eloquent\Relations\BelongsToMany
    {
        return $this->belongsToMany(Brand::class)->withTimestamps();
    }

    public function scopeParents($query , $parent_id = null)
    {
        return $query->where('parent_id' , $parent_id);
    }

    public function scopeSpecial($query)
    {
        return $query->where('special' , true);
    }

    public function scopeActive($query)
    {
        return $query->where('status', true);
    }

    public function registerMediaCollections(): void
    {
         $this->addMediaCollection('category')->singleFile();
         $this->addMediaCollection('icon')->singleFile();
    }

    public function addImage($file)
    {
        $this->addMedia($file)
            ->withCustomProperties(['type' => 'category'])
            ->toMediaCollection('category_image');
    }

    public function addIcon($file)
    {
        $this->addMedia($file)
            ->withCustomProperties(['type' => 'category'])
            ->toMediaCollection('category_icon');
    }

    public function getImageAttribute()
    {
        if (!$this->relationLoaded('media')) {
            return new DontAppend('Category getImageAttribute');
        }
        $image = $this->getFirstMedia('category_image');
        if (!$image) return null;

        return new MediaResource($image);
    }

    public function getIconAttribute()
    {
        if (!$this->relationLoaded('media')) {
            return new DontAppend('Category getIconAttribute');
        }
        $icon = $this->getFirstMedia('category_icon');
        if (!$icon) return null;

        return new MediaResource($icon);
    }

    public function products()
    {
        return $this->belongsToMany(Product::class);
    }

    public static function sort(array $categoryIds, $parentId = null)
    {
        $order = 999999;
        foreach ($categoryIds as $categoryId) {
            $category = Category::find($categoryId['id']);
            $category->parent_id = $parentId;
            if (!$category) continue;
            $category->priority = $order--;
            $category->save();
            if (isset($categoryId['children'])) {
                static::sort($categoryId['children'], $category->id);
            }
        }
    }
}
