<?php

return [
    'name' => 'Instagram'
];
