<?php

namespace Modules\Contact\Entities;

use Modules\Core\Entities\Repository as BaseRepository;

class Repository extends BaseRepository
{

    public function model()
    {
        return Contact::class;
    }
}
