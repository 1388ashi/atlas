<?php

namespace Modules\Contact\Entities;

use Modules\Core\Entities\BaseModel as Model;

class Contact extends Model
{
    protected $fillable = [
        'name',
        'phone_number',
        'subject',
        'body'
    ];
}
