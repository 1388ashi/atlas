<?php

namespace Modules\Contact\Http\Controllers\Admin;

use Illuminate\Routing\Controller;
use Illuminate\Contracts\Support\Renderable;
use Modules\Contact\Entities\Contact;
use Modules\Contact\Entities\Repository;

class ContactController extends Controller
{
    private $repository;

    public function __construct(Repository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        return response()->success('', ['contacts' => $this->repository->paginate()]);
    }

    /**
     * Show the specified resource.
     * @param Contact $contact
     * @return \Illuminate\Http\JsonResponse
     */
    public function show(Contact $contact)
    {
        return response()->success('', ['contact' => $contact]);
    }

    public function read(Contact $contact)
    {
        $contact->status = 1;
        $contact->save();

        return response()->success('وضعیت به خوانده شده تغییر کرد', ['contact' => $contact]);
    }

    /**
     * Remove the specified resource from storage.
     * @param Contact $contact
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(Contact $contact)
    {
        $this->repository->delete($contact);

        return response()->success('پیام با موفقیت حذف شد');
    }
}
