<?php

namespace Modules\Contact\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
use Modules\Auth\Rules\MobileRule;
use Modules\Core\Helpers\Helpers;
use Modules\Core\Rules\IranMobile;

class ContactRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|string',
            'phone_number' => ['required', new IranMobile()],
            'subject' => 'required|string',
            'body' => 'required|string'
        ];
    }
}
