<?php

return [
    'name' => 'User',
    'email_address' => env('MAIL_FROM_ADDRESS')
];
