<?php

namespace Modules\Coupon\Http\Controllers\Admin;

use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controller;
use Modules\Core\Helpers\Helpers;
use Modules\Coupon\Entities\Coupon;
use Modules\Coupon\Http\Requests\Admin\CouponStoreRequest;
use Modules\Coupon\Http\Requests\Admin\CouponUpdateRequest;

class CouponController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return JsonResponse
     */
    public function index(): JsonResponse
    {
        $coupons = Coupon::withCommonRelations()->filters()->paginateOrAll();

        return response()->success('لیست تمام کد تخفیف ها.', compact('coupons'));
    }

    /**
     * Store a newly created resource in storage.
     * @param CouponStoreRequest $request
     * @param Coupon $coupon
     * @return JsonResponse
     */
    public function store(CouponStoreRequest $request, Coupon $coupon): JsonResponse
    {
        Helpers::toCarbonRequest(['start_date', 'end_date'], $request);

        $coupon->fill($request->all())->save();

        return response()->success('کد تخفیف با موفقیت ایجاد شد.', compact('coupon'));
    }

    /**
     * Show the specified resource.
     * @param Coupon $coupon
     * @return JsonResponse
     */
    public function show(Coupon $coupon): JsonResponse
    {
        return response()->success('کد تخفیف با موفقیت بروزرسانی شد.', compact('coupon'));
    }

    /**
     * Update the specified resource in storage.
     * @param CouponUpdateRequest $request
     * @param Coupon $coupon
     * @return JsonResponse
     */
    public function update(CouponUpdateRequest $request, Coupon $coupon): JsonResponse
    {
        Helpers::toCarbonRequest(['start_date', 'end_date'], $request);

        $coupon->update($request->all());

        return response()->success('کد تخفیف با موفقیت بروزرسانی شد.', compact('coupon'));
    }

    /**
     * Remove the specified resource from storage.
     * @param Coupon $coupon
     * @return JsonResponse
     */
    public function destroy(Coupon $coupon): JsonResponse
    {
        $coupon->delete();

        return response()->success('کد تخفیف با موفقیت حذف شد.', compact('coupon'));
    }
}
