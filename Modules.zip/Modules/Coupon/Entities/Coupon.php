<?php

namespace Modules\Coupon\Entities;

use Illuminate\Support\Facades\DB;
use Modules\Core\Entities\BaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Core\Helpers\Helpers;
use Modules\Core\Traits\HasAuthors;
use Modules\Coupon\Http\Requests\Admin\CouponUpdateRequest;
use Modules\Customer\Entities\Customer;
use Spatie\Activitylog\LogOptions;

class Coupon extends BaseModel
{
    use HasFactory, HasAuthors;

    protected $fillable = [
        "title",
        "code",
        "start_date",
        "end_date",
        "type",
        "amount",
        "usage_limit",
        "usage_per_user_limit",
    ];

    protected static array $commonRelations = ['customers'];

    CONST DISCOUNT_TYPE_FLAT = 'flat';
    CONST DISCOUNT_TYPE_PERCENTAGE = 'percentage';

    public function getActivitylogOptions(): LogOptions
    {
        $admin = \Auth::user();
        $name = !is_null($admin->name) ? $admin->name : $admin->username;
        return LogOptions::defaults()
            ->useLogName('Coupon')->logAll()->logOnlyDirty()
            ->setDescriptionForEvent(function($eventName) use ($name){
                $eventName = Helpers::setEventNameForLog($eventName);
                return "انبار {$this->title} توسط ادمین {$name} {$eventName} شد";
            });
    }

    # Relation Functions
    public function customers(): \Illuminate\Database\Eloquent\Relations\BelongsToMany
    {
        return $this->belongsToMany(Customer::class)->withTimestamps();
    }
    #End Relations

    #Other Functions
    public static function getAvailableTypes(): array
    {
        return [static::DISCOUNT_TYPE_FLAT, static::DISCOUNT_TYPE_PERCENTAGE];
    }

    /**
     * @param int|Coupon $coupon
     * @return int
     */
    public function countCouponUsed(int|Coupon $coupon): int
    {
        if ($coupon instanceof Coupon){
            return $coupon->customers()->count();
        }

        return DB::table('coupon_customer')->where('coupon_id' , $coupon)->count();
    }

    /**
     * @param int|Customer $customer
     * @param int $couponId
     * @return int
     */
    public function countCouponUsedByCustomer(int|Customer $customer, int $couponId): int
    {
        if ($customer instanceof Customer){
            return $customer->coupons()->count();
        }

        return DB::table('coupon_customer')->where('customer_id' , $customer)
            ->where('coupon_id' , $couponId)->count();
    }
}
