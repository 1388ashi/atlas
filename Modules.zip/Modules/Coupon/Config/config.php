<?php

return [
    'name' => 'Coupon'
];
