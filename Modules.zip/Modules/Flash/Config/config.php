<?php

return [
    'name' => 'Flash'
];
