<?php

namespace Modules\Flash\Entities;

use Carbon\Carbon;
use DateTimeInterface;
use Modules\Admin\Entities\Admin;
use Modules\Core\Helpers\Helpers;
use Modules\Core\Traits\HasDefaultFields;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\MediaLibrary\HasMedia;
use Modules\Core\Traits\HasAuthors;
use Modules\Core\Entities\BaseModel;
use Spatie\EloquentSortable\Sortable;
use Modules\Product\Entities\Product;
use Spatie\EloquentSortable\SortableTrait;
use Modules\Core\Traits\InteractsWithMedia;
use Modules\Core\Transformers\MediaResource;
use Modules\Core\Entities\HasCommonRelations;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Flash extends BaseModel implements Sortable, HasMedia
{
    use HasFactory, HasCommonRelations, HasAuthors, LogsActivity,
        InteractsWithMedia, SortableTrait, HasDefaultFields;

    const DISCOUNT_TYPE_PERCENTAGE = 'percentage';
    const DISCOUNT_TYPE_FLAT = 'flat';

    CONST ACCEPTED_IMAGE_MIMES = 'gif|png|jpg|jpeg';

    protected $fillable = [
        'title',
        'start_date',
        'end_date',
        'preview_count',
        'order',
        'timer',
        'status'
    ];

    protected  $appends = ['image'];

    protected $hidden = ['media'];

    public $sortable = [
        'order_column_name' => 'order',
        'sort_when_creating' => true,
    ];

    protected $defaults = [
        'preview_count' => 7
    ];

    protected $dates = [
        'start_date', 'end_date'
    ];

    protected static $commonRelations = [
        'products'
    ];

    public function getActivitylogOptions(): LogOptions
    {
        $admin = \Auth::user();
        $name = !is_null($admin->name) ? $admin->name : $admin->username;
        return LogOptions::defaults()
            ->useLogName('Flash')->logAll()->logOnlyDirty()
            ->setDescriptionForEvent(function($eventName) use ($name){
                $eventName = Helpers::setEventNameForLog($eventName);
                return "کمپین {$this->title} توسط ادمین {$name} {$eventName} شد";
            });
    }

    protected function serializeDate(DateTimeInterface $date): string
    {
       return $date->format('Y-m-d H:i');
    }

    public static function getAvailableDiscountTypes()
    {
        return [static::DISCOUNT_TYPE_PERCENTAGE, static::DISCOUNT_TYPE_FLAT];
    }

    public static function booted()
    {
        static::deleting(function (Flash $flash) {
            //todo unable delete
        });

        Helpers::clearCacheInBooted(static::class, 'home_flash');

    }

    protected static function newFactory()
    {
        return \Modules\Flash\Database\factories\FlashFactory::new();
    }

    public function scopeActive($query)
    {
        return $query->whereDate('start_date', '<=', today())
            ->whereDate('end_date', '>=', today())
            ->where('status', '=', 1);
    }

    //Media library

    public function registerMediaCollections() : void
    {
        $this->addMediaCollection('image')->singleFile();
    }

    public function addImage($file)
    {
        return $this->addMedia($file)
            ->withCustomProperties(['type' => 'flash'])
            ->toMediaCollection('image');
    }

    public function getImageAttribute()
    {
        $media = $this->getFirstMedia('image');
        if (!$media) {
            return null;
        }
        return new MediaResource($media);
    }

    //Relations

    public function products()
    {
        return $this->belongsToMany(Product::class)
            ->withPivot(['discount_type', 'discount', 'salable_max'])->with('varieties');
    }
}
