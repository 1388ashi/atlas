<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Modules\Flash\Entities\Flash;

class CreateFlashProductTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('flash_product', function (Blueprint $table) {
            $table->id();
            $table->foreignId('flash_id')->constrained()->cascadeOnDelete();
            $table->foreignId('product_id')->constrained()->cascadeOnDelete();
            $table->enum('discount_type', Flash::getAvailableDiscountTypes());
            $table->unsignedInteger('discount');
            $table->unsignedInteger('salable_max')->nullable(); //if null, it's unlimited
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('flash_product');
    }
}
