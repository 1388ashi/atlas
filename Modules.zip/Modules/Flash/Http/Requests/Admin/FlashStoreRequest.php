<?php

namespace Modules\Flash\Http\Requests\Admin;

use Illuminate\Validation\Rule;
use Modules\Core\Helpers\Helpers;
use Modules\Flash\Entities\Flash;
use Modules\Product\Entities\Product;
use Modules\Core\Rules\Base64OrMediaId;
use Illuminate\Foundation\Http\FormRequest;
use Modules\Flash\Services\Validations\FlashProductsValidationService;
use Modules\Product\Services\Validations\DiscountValidationService;

class FlashStoreRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $discountRule = $this->discount_type === 'flat' ?
            'nullable|integer|min:1' :
            'nullable|integer|min:1|max:100';


        $discountTypes = Flash::getAvailableDiscountTypes();

        return [
            'title' => 'bail|required|string|max:191|unique:flashes',
            'start_date' => 'required|date_format:Y-m-d H:i|after_or_equal:today',
            'end_date' => 'required|date_format:Y-m-d H:i|after:start_date',
            'image' => ['required', new Base64OrMediaId()],
            'preview_count' => 'nullable|integer',
            'timer' => 'required|boolean',
            'status' => 'required|boolean',
            'discount_type' => ['required', Rule::in($discountTypes)],
            'discount' => $discountRule,
            //products
            'products' => 'required|array',
            'products.*.id' => [
                'bail',
                'required',
                'integer',
                Rule::exists('products', 'id')->where(function ($query) {
                    return $query->where('status', Product::STATUS_AVAILABLE);
                })
            ],
            'products.*.discount_type' => ['nullable', Rule::in($discountTypes)],
            'products.*.discount' => 'nullable|integer',
            'products.*.salable_max' => 'nullable|integer',
        ];
    }


    protected function prepareForValidation()
    {
        $this->merge([
            'timer' => $this->timer ? 1 : 0,
            'status' => $this->status ? 1 : 0
        ]);
    }

    public function passedValidation()
    {
        new FlashProductsValidationService($this->input('products'));
        foreach ($this->products as $key => $product) {
            if(($product['discount_type'] == Flash::DISCOUNT_TYPE_FLAT)){
                $baseProduct = Product::query()->findOrFail($product['id']);
                $varieties = $baseProduct->varieties;
                foreach ($varieties as $variety) {
                   if (($variety->price < $product['discount']) || ($variety->price < $this->discount)){
                       throw Helpers::makeValidationException('مقدار تخفیف از تنوع های محصول بیتشر می باشد.');
                   }
                }
            }
            if (($product['discount_type'] == Flash::DISCOUNT_TYPE_PERCENTAGE) && !($product['discount'] < 100 && $product['discount'] > 1)){
                $key  +=1;
                throw Helpers::makeValidationException("تخفیف محصول شمار {$key} باید بین 1 تا 100 باشد");
            }
        }
    }
}
