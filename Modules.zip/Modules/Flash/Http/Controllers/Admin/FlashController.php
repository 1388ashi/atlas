<?php

namespace Modules\Flash\Http\Controllers\Admin;

use Carbon\Carbon;
use DB;
use Exception;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Routing\Controller;
use Modules\Flash\Entities\Flash;
use Modules\Flash\Http\Requests\Admin\FlashStoreRequest;
use Modules\Flash\Http\Requests\Admin\FlashUpdateRequest;

class FlashController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $flashes = Flash::withCommonRelations()
            ->latest('id')
            ->filters()
            ->when(request('active'), function (Builder $query) {
                $now = Carbon::now();
                return $query->whereDate('start_date', '>=', $now)
                    ->whereDate('end_date', '<=', $now)
                    ->where('status', '=', 1);
            })
            ->paginateOrAll();

        return response()->success('Get all flashes', compact('flashes'));
    }

    /**
     * Store a newly created resource in storage.
     * @param FlashStoreRequest $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Throwable
     */
    public function store(FlashStoreRequest $request)
    {
        DB::beginTransaction();
        try {

            $flash = Flash::create($request->all());

            //Media
            if ($request->hasFile('image')) {
                $flash->addImage($request->image);
            }
            $flash->load('media');

            //Attach products
            foreach ($request->products as $product) {
                $flash->products()->attach($product['id'], [
                    'discount_type' => $product['discount_type'] ?? $request->input('discount_type'),
                    'discount' => $product['discount'] ?? $request->input('discount'),
                    'salable_max' => $product['quantity']
                ]);
            }

            DB::commit();
        } catch (Exception $exception) {
            DB::rollBack();
            return response()->error('مشکلی در ثبت فروش ویژه به وجود آمده است: ' . $exception->getMessage());
        }

        return response()->success('فروش ویژه با موفقیت ثبت شد', compact('flash'));
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $flash = Flash::findOrFail($id);
        $flash->loadCommonRelations();

        return response()->success('فروش ویژه با موفقیت دریافت شد', compact('flash'));
    }

    /**
     * Update the specified resource in storage.
     * @param FlashUpdateRequest $request
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     * @throws \Throwable
     */
    public function update(FlashUpdateRequest $request, $id)
    {
        DB::beginTransaction();
        try {

            $flash = Flash::findOrFail($id);

            $flash->fill($request->all());
            if ($request->hasFile('image')) {
                $flash->addImage($request->image);
            }
            $flash->save();

            //sync products
            $products = [];
            foreach ($request->products as $product) {
                $products[$product['id']] = [
                    'discount_type' => $product['discount_type'] ?? $request->input('discount_type'),
                    'discount' => $product['discount'] ?? $request->input('discount'),
                    'salable_max' => $product['quantity']
                ];
            }
            $flash->products()->sync($products);

            DB::commit();
        } catch (Exception $exception) {
            DB::rollBack();
            return response()->error('مشکلی در به روزرسانی فروش ویژه به وجود آمده است: ' . $exception->getMessage());
        }

        return response()->success('فروش ویژه با موفقیت به روزرسانی شد', compact('flash'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($id)
    {
        $flash = Flash::findOrFail($id);

        $flash->delete();

        return response()->success('فروش ویژه با موفقیت حذف شد');
    }
}
