<?php

namespace Modules\Color\Entities;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Core\Entities\BaseModel;
use Modules\Core\Entities\HasCommonRelations;
use Modules\Core\Traits\HasAuthors;
use Modules\Product\Entities\Variety;

class Color extends BaseModel
{
    use HasFactory, HasAuthors, HasCommonRelations;

    protected static $commonRelations = [
        //'products'
    ];

    protected $fillable = [
        'name', 'code', 'status', 'creator_id', 'updater_id'
    ];

    protected static function newFactory()
    {
        return \Modules\Color\Database\factories\ColorFactory::new();
    }

    public static function booted()
    {
        static::deleting(function (Color $color) {
            //check conditions
//            if ($color) {
//                throw new ModelCannotBeDeletedException('این رنگ قابل حذف نمی باشد.');
//            }
        });
    }

    public function variety(): \Illuminate\Database\Eloquent\Relations\BelongsToMany
    {
        return $this->belongsToMany(Variety::class);
    }

    /**
     * Scope a query to only include active users.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('status', 1);
    }
}
