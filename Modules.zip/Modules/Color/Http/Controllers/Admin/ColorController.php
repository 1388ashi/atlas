<?php

namespace Modules\Color\Http\Controllers\Admin;

use Illuminate\Routing\Controller;
use Modules\Color\Entities\Color;
use Modules\Color\Http\Requests\Admin\ColorStoreRequest;
use Modules\Color\Http\Requests\Admin\ColorUpdateRequest;

class ColorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $colors = Color::withCommonRelations()->latest('id')->filters()->paginateOrAll();

        return response()->success('دریافت لیست همه رنگ ها', compact('colors'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param ColorStoreRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(ColorStoreRequest $request)
    {
        $color = Color::create($request->all());

        return response()->success('رنگ با موفقیت ثبت شد.', compact('color'));
    }

    /**
     * Show the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $color = Color::findOrFail($id);

        return response()->success('رنگ با موفقیت دریافت شد.', compact('color'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param ColorUpdateRequest $request
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(ColorUpdateRequest $request, $id)
    {
        $color = Color::findOrFail($id);

        $color->update($request->all());

        return response()->success('رنگ با موفقیت به روزرسانی شد.', compact('color'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $color = Color::findOrFail($id);

        $color->delete();

        return response()->success('رنگ با موفقیت حذف شد.', compact('color'));
    }
}
