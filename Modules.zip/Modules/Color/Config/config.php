<?php

return [
    'name' => 'Color'
];
