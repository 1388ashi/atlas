<?php

return [
    'name' => 'Brand'
];
