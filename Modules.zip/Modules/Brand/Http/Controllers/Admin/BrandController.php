<?php

namespace Modules\Brand\Http\Controllers\Admin;

use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\Brand\Entities\Brand;
use Modules\Brand\Http\Requests\Admin\BrandStoreRequest;
use Modules\Brand\Http\Requests\Admin\BrandUpdateRequest;

class BrandController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return  mixed
     */
    public function index()
    {
        $brands = Brand::latest()->filters()->paginateOrAll();

        return response()->success('لیست تمامی برند ها', compact('brands'));
    }

    /**
     * Store a newly created resource in storage.
     * @param BrandStoreRequest $request
     * @param Brand $brand
     * @return mixed
     */
    public function store(BrandStoreRequest $request, Brand $brand)
    {
        $brand->fill($request->all());
        $brand->save();
        if ($request->hasFile('image')){
            $brand->addImage($request->image);
        }
        $brand->load('media');

        return response()->success('برند شما با موفقیت ایجاد شد.', compact('brand'));
    }

    /**
     * Show the specified resource.
     * @param $id
     * @return JsonResponse
     */
    public function show($id): JsonResponse
    {
        $brand = Brand::query()->findOrFail($id);

        return response()->success('', compact('brand'));
    }

    /**
     * Update the specified resource in storage.
     * @param BrandUpdateRequest $request
     * @param Brand $brand
     * @return Response
     */
    public function update(BrandUpdateRequest $request, $id)
    {
        $brand = Brand::query()->findOrFail($id);

        $brand->fill($request->all());
        if ($request->hasFile('image')){
            $brand->addImage($request->image);
        }
        $brand->save();

        return response()->success('برند مورد نظر بروزرسانی شد.', compact('brand'));
    }

    /**
     * Remove the specified resource from storage.
     * @param Brand $brand
     * @return Response
     * @throws Exception
     */
    public function destroy($id)
    {
        $brand = Brand::query()->findOrFail($id);

        $brand->delete();

        return response()->success('برند با موفقیت حذف شد.', compact('brand'));
    }
}
