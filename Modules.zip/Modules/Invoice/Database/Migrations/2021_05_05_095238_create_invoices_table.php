<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInvoicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            if (config('invoice.float')) {
                $table->float('amount', 20, 2);
            } else {
                $table->unsignedBigInteger('amount');
            }
            $table->enum('type', ['gateway', 'wallet']);
            $table->foreignId('payable_id');
            $table->string('payable_type');
            $table->string('transaction_id')->nullable();
            $table->enum('status', ['pending', 'failed', 'success']);
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('invoices');
    }
}
