<?php

return [
    'name' => 'Invoice',
    'float' => false,
    'invoice_expire_time' => 3600, // Timestamp - 60 minutes
    'payment_expire_time' => 900, // Timestamp - 15 minutes
    'default_diver' => 'virtual',

    'drivers' => [
        'virtual' => [
            'enabled' => true,
            'model' => \Modules\Invoice\Drivers\VirtualDriver::class,
            'label' => 'مجازی',
            'image' => '/assets/images/drivers/virtual.png',
            'options' => []
        ]
    ]
];
