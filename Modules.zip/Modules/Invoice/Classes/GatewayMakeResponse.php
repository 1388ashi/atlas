<?php


namespace Modules\Invoice\Classes;


use JetBrains\PhpStorm\ArrayShape;

class GatewayMakeResponse implements \Modules\Invoice\Contracts\GatewayMakeResponse
{
    public function __construct(public bool $success, public string $transactionId,
                                public string $url,
                                public string $message = '') {}


    public function getResult(): array
    {
        return [
            'success' => $this->success,
            'transaction_id' => $this->transactionId,
            'message' => $this->message,
            'url' => $this->url
        ];
    }
}
