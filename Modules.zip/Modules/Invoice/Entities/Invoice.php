<?php


namespace Modules\Invoice\Entities;


use Bavix\Wallet\Interfaces\Customer;
use Bavix\Wallet\Interfaces\Product;
use Bavix\Wallet\Models\Transfer;
use Bavix\Wallet\Traits\HasWallet;
use Modules\Admin\Entities\Admin;
use Modules\Core\Entities\BaseModel;
use Modules\Core\Entities\HasCommonRelations;
use Modules\Core\Helpers\Helpers;
use Modules\Invoice\Classes\Payable;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class Invoice
 * @package Modules\Bonusme\Entities
 * @property Payable $payable
 * @see Payment
 */
class Invoice extends BaseModel implements Product
{
    use HasCommonRelations, HasWallet, LogsActivity;

    protected $fillable = [
        'amount',
        'type',
        'transaction_id',
        'status'
    ];

    protected static $commonRelations = [
        'payable'
    ];

    const STATUS_PENDING = 'pending';
    const STATUS_FAILED = 'failed';
    const STATUS_SUCCESS = 'success';

    public function getActivitylogOptions(): LogOptions
    {
        $admin = \Auth::user() ?? Admin::query()->first();
        $name = !is_null($admin->name) ? $admin->name : $admin->username;
        return LogOptions::defaults()
            ->useLogName('Invoice')->logAll()->logOnlyDirty()
            ->setDescriptionForEvent(function($eventName) use ($name){
                $eventName = Helpers::setEventNameForLog($eventName);
                return "فاکتور با شناسه {$this->id} توسط ادمین {$name} {$eventName} شد";
            });
    }

    public function payable()
    {
        return $this->morphTo();
    }

    public function payments(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function isExpired()
    {
        return false;
    }

    public function scopePendingPaid($query)
    {
        $query->where('status', static::STATUS_PENDING);
    }

    public static function storeByWallet(Payable $payable, Transfer $transfer = null, $status = 'success'): Invoice
    {
        $invoice = new Invoice([
            'amount' => $payable->getPayableAmount(),
            'type' => 'wallet',
            'transaction_id' => $transfer?->id,
            'status' => $status
        ]);
        $invoice->payable()->associate($payable);
        $invoice->save();

        return $invoice;
    }

    public function canBuy(Customer $customer, int $quantity = 1, bool $force = null): bool
    {
        return !$customer->paid($this);
    }

    public function getAmountProduct(Customer $customer)
    {
        return $this->getTotalAmount();
    }

    public function getMetaProduct(): ?array
    {
        return [
            'customer_name' => $this->payable->customer->full_name,
            'customer_mobile' => $this->payable->customer->mobile,
            'description' => $this->payable->payDescription ?: 'خرید سفارش به شماره #' . $this->id
        ];
    }

    public function getUniqueId(): string
    {
        return (string) $this->getKey();
    }

    public function getTotalAmount()
    {
        $totalItemsAmount = $this->payable->activeItems
            ->reduce(function ($total, $item) {
                return $total + ($item->amount * $item->quantity);
            });
        if (!is_null($this->payable->reserved_id)){
            $amount = ($totalItemsAmount) - $this->payable->attributes['discount_amount'];
        }else{
            $amount = ($totalItemsAmount + $this->payable->attributes['shipping_amount']) - $this->payable->attributes['discount_amount'];
        }

        return $amount;
    }
}
