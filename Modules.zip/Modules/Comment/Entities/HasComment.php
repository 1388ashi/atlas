<?php

namespace Modules\Comment\Entities;

interface HasComment
{

}
