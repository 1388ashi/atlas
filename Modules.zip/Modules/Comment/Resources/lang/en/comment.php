<?php
return [
    'store' => 'Comment sent successfully',

    'admin' => [
        'delete' => 'Comment deleted successfully',
        'update' => 'Comment updated successfully',
    ]
];
