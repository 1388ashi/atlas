<?php

namespace Modules\Comment\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Modules\Comment\Entities\Comment;
use Modules\Comment\Http\Requests\Admin\CommentAnswerRequest;
use Modules\Comment\Http\Requests\Admin\CommentUpdateRequest;
use Modules\Core\Helpers\Helpers;

class CommentController extends Controller
{
    public function index($model)
    {
        $commentBuilder = $model->comments()->latest()->with('children')->with('parent')->without('children');
        $comments = Helpers::paginateOrAll($commentBuilder);
        $comments->load('parent');

        return response()->success('',  compact('comments'));
    }

    public function all()
    {
        $commentBuilder = Comment::latest()->with('children')->with('commentable', 'parent');
        $comments = $commentBuilder->paginate(10);

        return response()->success('', compact('comments'));
    }

    public function show($id)
    {
        $comment = Comment::with('commentable')->with('children')->findOrFail($id);

        return response()->success('', compact('comment'));
    }

    public function answer($id, CommentAnswerRequest $request)
    {
        $oldComment = Comment::without('children')->findOrFail($id);
        if ($oldComment->parent_id) {
            return response()->error('امکان پاسخگویی به جواب وجود ندارد', [], 400);
        }
        $comment = new Comment();
        $comment->fill($request->all());
        $comment->creator()->associate(Auth::guard('admin-api')->user());
        $comment->parent()->associate($oldComment);
        $comment->commentable()->associate($oldComment->commentable);
        $comment->save();

        return response()->success('پاسخ با موفقیت ثبت شد',  compact('comment'));
    }

    public function update($id, CommentUpdateRequest $request) {
        $comment = Comment::with('commentable', 'creator')->without('children')->findOrFail($id);
        $comment->update($request->only(['name', 'email', 'body', 'status']));

        return response()->success(trans('comment::comment.admin.update'),  compact('comment'));
    }

    public function destroy(Comment $comment)
    {
        $comment->delete();

        return response()->success(trans('comment::comment.admin.delete'), null);
    }
}
