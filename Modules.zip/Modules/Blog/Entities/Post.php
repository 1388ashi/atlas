<?php

namespace Modules\Blog\Entities;

use AshAllenDesign\ShortURL\Models\ShortURL;
use Cviebrock\EloquentSluggable\Sluggable;
use CyrildeWit\EloquentViewable\Contracts\Viewable;
use CyrildeWit\EloquentViewable\InteractsWithViews;
use Modules\Admin\Entities\Admin;
use Modules\Comment\Entities\Commentable;
use Modules\Comment\Entities\HasComment;
use Modules\Core\Entities\BaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Core\Entities\HasCommonRelations;
use Modules\Core\Helpers\Helpers;
use Modules\Core\Traits\HasMorphAuthors;
use Modules\Core\Traits\InteractsWithMedia;
use Modules\Core\Transformers\MediaResource;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\EloquentSortable\Sortable;
use Spatie\EloquentSortable\SortableTrait;
use Spatie\MediaLibrary\HasMedia;
use Spatie\Tags\HasTags;

class Post extends BaseModel implements Sortable, HasMedia, HasComment, Viewable
{
    use HasFactory, HasMorphAuthors, Sluggable, HasCommonRelations, SortableTrait,
        InteractsWithMedia, Commentable, HasTags, InteractsWithViews, LogsActivity;

    const STATUS_DRAFT = 'draft';

    const STATUS_PENDING = 'pending';

    const STATUS_PUBLISHED = 'published';

    const STATUS_UNPUBLISHED = 'unpublished';

    protected  $appends = ['image'];

    protected $hidden = ['media'];

    public $sortable = [
        'order_column_name' => 'order',
        'sort_when_creating' => true,
    ];

    protected $withCount = ['comments'];

    protected static $commonRelations = [
        'category', 'tags', 'comments', 'creator'
    ];

    protected $fillable = [
        'title',
        'slug',
        'summary',
        'order',
        'body',
        'meta_description',
        'status',
        'special',
        'published_at'
    ];

    protected $dates = [
        'published_at'
    ];

    protected $allFields = [
        'id',
        'title',
        'slug',
        'summary',
        'order',
        'body',
        'meta_description',
        'status',
        'special',
        'published_at',
        'created_at',
        'updated_at',
        'creatorable_id',
        'updaterable_id'
    ];

    protected $longFields = [
        'body'
    ];

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'title'
            ]
        ];
    }

    public static function booted()
    {
        static::deleted(function (Post $post) {
            $post->tags()->delete();
            $post->comments()->delete();
        });
        Helpers::clearCacheInBooted(static::class , 'home_post');
    }

    public function getActivitylogOptions(): LogOptions
    {
        $admin = \Auth::user();
        $name = !is_null($admin->name) ? $admin->name : $admin->username;
        return LogOptions::defaults()
            ->useLogName('Blog')->logAll()->logOnlyDirty()
            ->setDescriptionForEvent(function($eventName) use ($name){
                $eventName = Helpers::setEventNameForLog($eventName);
                return "پست {$this->title} توسط ادمین {$name} {$eventName} شد";
            });
    }

    protected static function newFactory()
    {
        return \Modules\Blog\Database\factories\PostFactory::new();
    }

    public static function getAvailableStatuses()
    {
        return [
            static::STATUS_DRAFT,
            static::STATUS_PENDING,
            static::STATUS_PUBLISHED,
            static::STATUS_UNPUBLISHED
        ];
    }

    //Media library

    public function registerMediaCollections() : void
    {
        $this->addMediaCollection('image')->singleFile();
    }

    public function addImage($file)
    {
        return $this->addMedia($file)
            ->withCustomProperties(['type' => 'post'])
            ->toMediaCollection('image');
    }

    public function getImageAttribute(): ?MediaResource
    {
        $media = $this->getFirstMedia('image');
        if (!$media) {
            return null;
        }
        return new MediaResource($media);
    }

    public function scopePublished($query)
    {
        $query->where('status', static::STATUS_PUBLISHED)
            ->whereDate('published_at', '<=', now());
    }



    //Relations

    public function category()
    {
        return $this->belongsTo(PostCategory::class, 'post_category_id');
    }

    public function scopeIndex($query, $longFields = null)
    {
        $longFields = $longFields ?? $this->longFields;

        $query->select(array_diff($this->allFields, $longFields));
    }
}
