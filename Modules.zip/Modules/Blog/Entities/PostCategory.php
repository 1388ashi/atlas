<?php

namespace Modules\Blog\Entities;

use Cviebrock\EloquentSluggable\Sluggable;
use Modules\Core\Exceptions\ModelCannotBeDeletedException;
use Spatie\EloquentSortable\Sortable;
use Spatie\EloquentSortable\SortableTrait;
use Modules\Core\Traits\HasAuthors;
use Modules\Core\Entities\BaseModel;
use Modules\Core\Entities\HasCommonRelations;
use Illuminate\Database\Eloquent\Factories\HasFactory;


class PostCategory extends BaseModel implements Sortable
{
    use HasFactory, HasAuthors, HasCommonRelations, SortableTrait, Sluggable;

    protected $fillable = [
        'name', 'slug', 'status'
    ];

    public $sortable = [
        'order_column_name' => 'order',
        'sort_when_creating' => true,
    ];

    protected static $commonRelations = [
        'posts'
    ];

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }

    protected static function newFactory()
    {
        return \Modules\Blog\Database\factories\PostCategoryFactory::new();
    }

    /**
     * Perform any actions required after the model boots.
     *
     * @return void
     */
    public static function booted()
    {
        static::deleting(function (PostCategory $postCategory) {
            if ($postCategory->posts()->count() > 0) {
                throw new ModelCannotBeDeletedException('این دسته بندی دارای مطلب می باشد و نمی تواند حذف شود.');
            }
        });
    }

    public function scopeActive($query)
    {
        return $query->where('status', 1);
    }

    //Relations

    public function posts()
    {
        return $this->hasMany(Post::class, 'post_category_id');
    }
}
