<?php

namespace Modules\Blog\Http\Controllers\Front;

use Carbon\Carbon;
use Illuminate\Routing\Controller;
use Modules\Blog\Entities\Post;
use Modules\Blog\Entities\PostCategory;
use Modules\Comment\Entities\Comment;

class PostController extends Controller
{
    public function index()
    {
        $posts = Post::published()
            ->with(['category' => function ($query) {
                $query->select(['id', 'name']);
            }])
            ->withCount('views')
            ->filters()
            ->select(['id', 'title', 'summary', 'slug', 'special', 'created_at', 'post_category_id'])
            ->paginateOrAll(12);

        $category  = PostCategory::query()->active()->get();

        return response()->success('', compact('posts', 'category'));
    }

    public function show($id)
    {
        $user = auth()->user();
        $getPost = Post::query()->published()->findOrFail($id)->loadCommonRelations();
        $getPost->setAttribute('viewCount', views($getPost)->count());
        views($getPost)->record();

        if ($getPost->status != Post::STATUS_PUBLISHED || Carbon::now()->lt($getPost->published_at)) {
            return response()->error('دسترسی به این مطلب امکان پذیر نیست', [], 403);
        }

        $category  = PostCategory::query()->active()->get();
        $suggests  = Post::query()->published()
            ->where('post_category_id',  $getPost->post_category_id)
            ->where('id', '!=' ,$getPost->id)
            ->inRandomOrder()->take(3)->get();
        $lastPost  = Post::query()->select(['id', 'title', 'slug', 'created_at'])->published()
            ->where('id', '!=', $getPost->id)->latest()->take(10)->get();

        $post = [
            'post' => $getPost,
            'category' => $category,
            'suggests' => $suggests,
            'lastPost' => $lastPost,
            'user' => $user
        ];

        return response()->success('', compact('post'));
    }

    public function byCategory($category_id): \Illuminate\Http\JsonResponse
    {
        $posts = Post::query()->where('post_category_id', $category_id)->published()
            ->with(['category' => function ($query) use ($category_id){
                $query->select(['id', 'name']);
            }])
            ->filters()
            ->select(['id', 'title', 'summary', 'slug', 'special', 'created_at', 'post_category_id'])
            ->paginateOrAll();
        $category  = PostCategory::query()->active()->get();

        return response()->success('', compact('posts', 'category'));
    }
}
