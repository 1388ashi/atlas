<?php

namespace Modules\Blog\Http\Controllers\Admin;

use Exception;
use Modules\Blog\Entities\Post;
use Illuminate\Routing\Controller;
use Modules\Blog\Entities\PostCategory;
use Modules\Blog\Http\Requests\Admin\Post\PostStoreRequest;
use Modules\Blog\Http\Requests\Admin\Post\PostUpdateRequest;

class PostController extends Controller
{
    public function index()
    {
        $posts = Post::withCommonRelations()->latest('id')->filters()->paginateOrAll();

        return response()->success('Get all posts', compact('posts'));
    }


    public function store(PostStoreRequest $request)
    {
        try {
            $category = PostCategory::findOrFail($request->post_category_id);
            $post = $category->posts()->create($request->all());
            //tags
            if ($request->tags) {
                $post->attachTags($request->tags);
            }
            //media
            if ($request->hasFile('image')) {
                $post->addImage($request->image);
            }
            $post->load('media', 'category');

            return response()->success('مطلب با موفقیت ثبت شد', compact('post'));
        } catch (Exception $exception) {
            return response()->error('مشکلی در برنامه رخ داده است:' . $exception->getMessage(), [], 500);
        }
    }


    public function show($id)
    {
        $post = Post::withCommonRelations()->findOrFail($id);

        return response()->success('مطلب با موفقیت دریافت شد', compact('post'));
    }


    public function update(PostUpdateRequest $request, $id)
    {
        try {
            $post = Post::findOrFail($id);
            $category = PostCategory::findOrFail($request->post_category_id);
            $post->category()->associate($category);
            $post->fill($request->all());
            if ($request->hasFile('image')) {
                $post->addImage($request->image);
            }
            $post->save();

            //tags
            if ($request->tags) {
                $post->syncTags($request->tags);
            }

            return response()->success('مطلب با موفقیت به روزرسانی شد', compact('post'));
        } catch (Exception $exception) {
            return response()->error('مشکلی در برنامه رخ داده است:' . $exception->getMessage(), [], 500);
        }
    }

    public function destroy($id)
    {
        $post = Post::findOrFail($id);
        $post->delete();

        return response()->success('مطلب با موفقیت حذف شد');
    }
}
