<?php

namespace Modules\Blog\Http\Controllers\Admin;

use Illuminate\Routing\Controller;
use Modules\Blog\Entities\PostCategory;
use Modules\Blog\Http\Requests\Admin\PostCategory\PostCategoryStoreRequest;
use Modules\Blog\Http\Requests\Admin\PostCategory\PostCategoryUpdateRequest;

class PostCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $postCategories = PostCategory::latest('id')
            ->filters()
            ->select(['id', 'name', 'status', 'order', 'created_at'])
            ->paginateOrAll();

        return response()->success('Get all post categories', compact('postCategories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param PostCategoryStoreRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(PostCategoryStoreRequest $request)
    {
        $postCategory = PostCategory::create($request->all());

        return response()->success('دسته بندی مطلب با موفقیت ثبت شد.', compact('postCategory'));
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $postCategory = PostCategory::findOrFail($id);

        return response()->success('دسته بندی مطلب با موفقیت دریافت شد.', compact('postCategory'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param PostCategoryUpdateRequest $request
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(PostCategoryUpdateRequest $request, $id)
    {
        $postCategory = PostCategory::findOrFail($id);

        $postCategory->update($request->all());

        return response()->success('دسته بندی مطلب با موفقیت به روزرسانی شد.', compact('postCategory'));
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($id)
    {
        $postCategory = PostCategory::findOrFail($id);

        $postCategory->delete();

        return response()->success('دسته بندی مطلب با موفقیت حذف شد.');
    }
}
