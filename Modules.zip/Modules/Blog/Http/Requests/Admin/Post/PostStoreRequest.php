<?php

namespace Modules\Blog\Http\Requests\Admin\Post;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Modules\Blog\Entities\Post;

class PostStoreRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title' => 'required|string|max:191',
            'post_category_id' => 'required|integer|exists:post_categories,id',
            'summary' => 'nullable|string|max:1000',
            'body' => 'required|string|max:64000',
            'image' => 'nullable|image|max:8000',
            'meta_description' => 'nullable|string|max:1000',
            'status' => ['required',
                Rule::in([Post::STATUS_DRAFT, Post::STATUS_PENDING, Post::STATUS_PUBLISHED, Post::STATUS_UNPUBLISHED])],
            'special' => 'required|boolean',
            'published_at' => 'nullable|date_format:Y/m/d',
            'tags' => 'nullable|array',
            'tags.*' => 'string|max:191'
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function prepareForValidation()
    {
        $this->merge([
            'special' => $this->special ? 1 : 0
        ]);
    }
}
