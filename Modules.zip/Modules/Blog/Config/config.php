<?php

return [
    'name' => 'Blog',
    'orderCacheTime' => 6000
];
