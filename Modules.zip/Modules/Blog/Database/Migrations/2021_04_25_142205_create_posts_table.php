<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Modules\Blog\Entities\Post;

class CreatePostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('posts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('post_category_id')->constrained()->cascadeOnDelete();
            $table->string('title')->index();
            $table->string('slug');
            $table->unsignedInteger('order')->nullable();
            $table->text('summary')->nullable();
            $table->longText('body');
            $table->string('image')->nullable();
            $table->text('meta_description')->nullable();
            $table->enum('status', Post::getAvailableStatuses());
            $table->boolean('special')->default(0);
            $table->timestamp('published_at')->useCurrent();
            $table->morphAuthors();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('posts');
    }
}
