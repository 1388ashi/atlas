<?php


namespace Modules\FAQ\Http\Requests\Admin;


use Illuminate\Foundation\Http\FormRequest;
use Modules\FAQ\Entities\FAQ;

class FAQStoreRequest extends FormRequest
{
    public function rules()
    {
        return [
            'question' => 'required|string',
            'answer' => 'required|string',
            'status' => 'required|boolean'
        ];
    }
}
