<?php


namespace Modules\FAQ\Http\Controllers\Front;


use App\Http\Controllers\Controller;
use Modules\Core\Helpers\Helpers;
use Modules\FAQ\Entities\FAQ;
use Modules\FAQ\Http\Requests\Admin\FAQStoreRequest;

class FAQController extends Controller
{
    public function index()
    {
        $fAQBuilder = FAQ::query();
        Helpers::applyFilters($fAQBuilder);
        $fAQs = Helpers::paginateOrAll($fAQBuilder);

        return response()->success('', compact('fAQs'));
    }

    public function show(FAQ $fAQ)
    {
        return response()->success('', compact('fAQ'));
    }
}
