<?php


namespace Modules\FAQ\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Core\Helpers\Helpers;
use Modules\FAQ\Entities\FAQ;
use Modules\FAQ\Http\Requests\Admin\FAQStoreRequest;

class FAQController extends Controller
{
    public function index()
    {
        $fAQBuilder = FAQ::query()->orderBy('order', 'desc');
        Helpers::applyFilters($fAQBuilder);
        $fAQs = $fAQBuilder->get();

        return response()->success('', compact('fAQs'));
    }

    public function store(FAQStoreRequest $fAQStoreRequest)
    {
        $fAQ = new FAQ();
        $fAQ->fill($fAQStoreRequest->all());
        $fAQ->save();

        return response()->success('سوال متداول با موفقیت ثبت شد', compact('fAQ'));
    }

    public function sort(Request $request)
    {
        $order = 999999;
        if (count($request->ids) != FAQ::query()->count()){
            return response()->error('مشخصه های وارد شده نامعتبر است');
        }
        foreach ($request->ids as $id) {
            $faq = FAQ::query()->find($id);
            $faq->order = $order--;
            $faq->save();
        }

        return response()->success('مرتب سازی با موفقیت انجام شد', null);
    }

    public function update(FAQStoreRequest $fAQStoreRequest, $fAQId)
    {
        $fAQ = FAQ::findOrFail($fAQId);
        $fAQ->fill($fAQStoreRequest->all());
        $fAQ->save();

        return response()->success('سوال متداول با موفقیت بروز شد', compact('fAQ'));
    }

    public function destroy($fAQId)
    {
        $fAQ = FAQ::findOrFail($fAQId);
        $fAQ->delete();

        return response()->success('سوال متداول با موفقیت حذف شد', null);
    }
}
