<?php

return [
    'name' => 'FAQ'
];
