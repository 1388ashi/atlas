<?php


namespace Modules\FAQ\Entities;

use Modules\Core\Entities\BaseModel;

class FAQ extends BaseModel
{
    protected $fillable = [
        'question',
        'answer',
        'status'
    ];

    protected $table = 'f_a_qs';


}
