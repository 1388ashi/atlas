<?php

namespace Modules\FAQ\Entities;

use Modules\Core\Entities\BaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class FAQCategory extends BaseModel
{
    use HasFactory;

    protected $fillable = [];

    protected static function newFactory()
    {
        return \Modules\FAQ\Database\factories\FAQCategoryFactory::new();
    }
}
